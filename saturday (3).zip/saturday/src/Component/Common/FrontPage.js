import React from "react";

import { Carousel } from "react-bootstrap";

import mixFruits from "./assest/mixFruits.webp";
import mixvegitables from "./assest/mixvegitables.webp";
import cold from "./assest/coldDrink.jpg";
import chips from "./assest/chips.webp";

const FrontPage = () => {
  return (
    // <div className="container">
    //   <div
    //     style={{
    //       display: "flex",
    //       justifyContent: "center",
    //       gap: 155,
    //       alignItems: "center",
    //     }}
    //   >
    //     <div>
    //       <h3>Easy way to make an order</h3>

    //       <h1>
    //         <span style={{ fontSize: 45 }}>
    //           <span style={{ colorL: "black", fontWeight: 900 }}>Buy</span> Just
    //           wait and <br />
    //         </span>
    //       </h1>

    //       <h3>
    //         order at{" "}
    //         <span style={{ colorL: "black", fontWeight: 900, fontSize: 45 }}>
    //           your door
    //         </span>
    //       </h3>
    //       <div style={{ display: "flex", gap: 45 }}>
    //         <button
    //           className="btn btn-dark"
    //           style={{ padding: "3px 15px", fontWeight: 700 }}
    //         >
    //           Order Now
    //         </button>
    //         <Link to="alldata">
    //           <button
    //             btn
    //             btn-outline-dark
    //             style={{
    //               padding: "3px 15px",
    //               borderRadius: 7,
    //               fontWeight: 700,
    //             }}
    //           >
    //              Category
    //           </button>
    //         </Link>
    //       </div>
    //     </div>
    //     <div>
    //       <img
    //         className="imagess"
    //         src="https://static.vecteezy.com/system/resources/thumbnails/005/337/737/small/icon-delivery-silhouette-illustration-free-vector.jpg"
    //         style={{ height: 360, width: 400 }}
    //       />
    //     </div>
    //   </div>

    //   <div style={{ display: "flex", gap: 35, marginLeft: 95 }}>
    //     <h6 style={{ fontWeight: 600 }}>
    //       <i class="fa-solid fa-truck-fast" style={{ fontSize: 20 }}>
    //         {" "}
    //       </i>{" "}
    //       No shipping charge
    //     </h6>

    //     <h6 style={{ fontWeight: 600 }}>
    //       <i class="fa-solid fa-shield-halved" style={{ fontSize: 20 }}></i>{" "}
    //       100% secure checkout
    //     </h6>
    //   </div>
    // </div>

    <div>
      <Carousel>
        <Carousel.Item>
     
          <img
            src={mixFruits}
            alt="First slide"
            style={{ height: 510, width: "100%" }}
          />
       
        </Carousel.Item>
        <Carousel.Item>
          <img
            src={mixvegitables}
            alt="First slide"
            style={{ height: 510, width: "100%" }}
          />
        </Carousel.Item>
        <Carousel.Item>
          <img
            src={cold}
            alt="First slide"
            style={{ height: 510, width: "100%" }}
          />
        </Carousel.Item>

        <Carousel.Item>
          <img
            src={chips}
            alt="First slide"
            style={{ height: 500, width: "100%" }}
          />
        </Carousel.Item>
      </Carousel>
    </div>
  );
};

export default FrontPage;
