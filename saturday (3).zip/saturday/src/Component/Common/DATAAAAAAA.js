import apple from "../Common/assest/Fruits/apple.webp";
import banana from "../Common/assest/Fruits/banana.avif";
import orange from "../Common/assest/Fruits/orange.jpg";
import mango from "../Common/assest/Fruits/mango.webp";
import pineapple from "../Common/assest/Fruits/pineapple.webp";
import strawberry from "../Common/assest/Fruits/strawberry.webp";
import graps from "../Common/assest/Fruits/graps.webp";
import watermelon from "../Common/assest/Fruits/watermelon.avif";
import kiwi from "../Common/assest/Fruits/kiwi.avif";
import pear from "../Common/assest/Fruits/pear.avif";
import dragon from "../Common/assest/Fruits/dragon.webp";
import pomegrante from "../Common/assest/Fruits/pomegrante.webp";
import blueberry from "../Common/assest/Fruits/blueberry.avif";
import star from "../Common/assest/Fruits/star.avif";
import lemon from "../Common/assest/Fruits/lemon.avif";

// vegi
import Carrot from "../Common/assest/Vegitables/Carrot.webp";
import Broccoli from "../Common/assest/Vegitables/Broccoli.avif";
import Spinach from "../Common/assest/Vegitables/Spinach.webp";
import Tomato from "../Common/assest/Vegitables/Tomato.avif";
import Cucumber from "../Common/assest/Vegitables/Cucumber.webp";
import Potato from "../Common/assest/Vegitables/Potato.webp";
import BellPepper from "../Common/assest/Vegitables/Bell Pepper.avif";
import Onion from "../Common/assest/Vegitables/Onion.webp";
import Mint from "../Common/assest/Vegitables/Mint.webp";
import Zucchini from "../Common/assest/Vegitables/Zucchini.avif";
import Kundru from "../Common/assest/Vegitables/Kundru.webp";
import Cabbage from "../Common/assest/Vegitables/Cabbage.avif";
import Corn from "../Common/assest/Vegitables/Corn.avif";
import GreenBeans from "../Common/assest/Vegitables/Green Beans.avif";
import Bitter from "../Common/assest/Vegitables/Bitter.avif";

// coldDrink
import CocaCola from "../Common/assest/colddrink/CocaCola.webp";
import Pepsi from "../Common/assest/colddrink/Pepsi.webp";
import Sprite from "../Common/assest/colddrink/Sprite.webp";
import Fanta from "../Common/assest/colddrink/Fanta.webp";
import Limca from "../Common/assest/colddrink/Limca.webp";
import PaperBoat from "../Common/assest/colddrink/PaperBoat.webp";
import SevenUp from "../Common/assest/colddrink/sevenUp.webp";
import RedBull from "../Common/assest/colddrink/RedBull.jpg";
import MonsterEnergy from "../Common/assest/colddrink/MonsterEnergy.webp";
import Stings from "../Common/assest/colddrink/Stings.jpg";
import Gatorade from "../Common/assest/colddrink/Gatorade.webp";
import Campa from "../Common/assest/colddrink/Campa.webp";
import Jira from "../Common/assest/colddrink/Jira.webp";
import Bisleri from "../Common/assest/colddrink/Bisleri.webp";
import Mazza from "../Common/assest/colddrink/Mazza.jpg";

// chipspacket
import LaysClassic from "../Common/assest/chipspacket/LaysClassic.webp";
import DoritosNachoCheese from "../Common/assest/chipspacket/DoritosNachoCheese.webp";
import PringlesOriginal from "../Common/assest/chipspacket/PringlesOriginal.webp";
import CheetosCrunchy from "../Common/assest/chipspacket/CheetosCrunchy.webp";
import Creameonion from "../Common/assest/chipspacket/Creameonion.webp";
import Mad from "../Common/assest/chipspacket/Mad.webp";
import Bingo from "../Common/assest/chipspacket/Bingo.webp";
import PotatopChips from "../Common/assest/chipspacket/PotatopChips.webp";
import CheeseBall from "../Common/assest/chipspacket/CheeseBall.webp";
import MadAngles from "../Common/assest/chipspacket/MadAngles.webp";
import Solted from "../Common/assest/chipspacket/Solted.webp";
import MasalaMasti from "../Common/assest/chipspacket/MasalaMasti.webp";
import Cornitos from "../Common/assest/chipspacket/Cornitos.webp";
import Makino from "../Common/assest/chipspacket/Makino.webp";
import Nachoz from "../Common/assest/chipspacket/Nachoz.jpg";

let DATAAAAAA = [
  // fruitsw
  {
    id: 1,
    name: "Apple",
    price: 250,
    old: 300,
    quantity: 1,
    image: apple,
    category: "Fruits",
    descripition:
      "The apple is one of the pome (fleshy) fruits. Apples at harvest vary widely in size, shape, colour, and acidity, but most are fairly round and some shade of red or yellow. The thousands of varieties fall into three broad classes: cider, cooking, and dessert varieties",
  },
  {
    id: 2,
    name: "Banana",
    price: 65,
    old: 85,
    quantity: 1,
    image: banana,
    category: "Fruits",
    descripition:
      "Bananas are long, curved fruits with smooth, yellow, and sometimes slightly green skin. The average length of a banana is about 7 to 9 inches, and it is about 2 to 3 inches in diameter. The skin of the banana is usually yellow when it is ripe, but it can also be green, red, or purple depending on the variety.",
  },
  {
    id: 3,
    name: "Orange",
    price: 130,
    old: 150,
    quantity: 1,
    image: orange,
    category: "Fruits",
    descripition:
      "Oranges are citrus fruits with fragrant, leathery skin and juicy flesh. The most common types are the sweet (or common) orange, the sour (or Seville) orange, and the mandarin orange. The sweet orange is the most widely grown citrus fruit in the world.",
  },
  {
    id: 4,
    name: "Mango",
    price: 390,
    old: 400,
    quantity: 1,
    image: mango,
    category: "Fruits",
    descripition:
      "Mango is the national fruit of India which is loved by one and all. It is a very juicy, pulpy and luscious fruit. Ripe mangoes can either be consumed raw or in the form of salad, juice, jams, milkshake or pickles. Mango is a rich source of various vitamins and minerals.",
  },
  {
    id: 5,
    name: "Pineapple",
    price: 140,
    old: 160,
    quantity: 1,
    image: pineapple,
    category: "Fruits",
    descripition:
      "Ananas comosus (L.) Merr (Bromeliaceae), known as pineapple, is a herbaceous, biennial, tropical plant that grows up to 1.0–1.5m high and produces a fleshy, edible fruit whose flesh ranges from nearly white to yellow.",
  },
  {
    id: 6,
    name: "Strawberry",
    price: 250,
    old: 270,
    quantity: 1,
    image: strawberry,
    category: "Fruits",
    descripition:
      "A strawberry is both a low-growing, flowering plant and also the name of the fruit that it produces. Strawberries are soft, sweet, bright red berries. They're also delicious. Strawberries have tiny edible seeds, which grow all over their surface.",
  },
  {
    id: 7,
    name: "Grape",
    price: 60,
    old: 75,
    quantity: 1,
    image: graps,
    category: "Fruits",
    descripition:
      "A grape is a fruit, botanically a berry, of genus Vitis and family Vitaceae. Grapes grow in clusters of 15–300 in different colors (crimson, black, dark blue, yellow, green, orange, pink, and white) and are specifically a nonclimacteric type and deciduous crop.",
  },
  {
    id: 8,
    name: "Watermelon",
    price: 85,
    old: 95,
    quantity: 1,
    image: watermelon,
    category: "Fruits",
    descripition:
      "Watermelon is grown in favorable climates from tropical to temperate regions worldwide for its large edible fruit, which is a berry with a hard rind and no internal divisions, and is botanically called a pepo. The sweet, juicy flesh is usually deep red to pink, with many black seeds, although seedless varieties exist.",
  },
  {
    id: 9,
    name: "Kiwi",
    price: 190,
    old: 240,
    quantity: 1,
    image: kiwi,
    category: "Fruits",
    descripition:
      "Kiwis are small, round, sweet fruits with brown, fuzzy skin. The inside is bright green, yellow, or red depending on the variety. There are also small, black seeds on the inside of the fruit. Kiwis taste best when they are slightly firm.",
  },
  {
    id: 10,
    name: "Pear",
    price: 350,
    old: 380,
    quantity: 1,
    image: pear,
    category: "Fruits",
    descripition:
      "pear, (genus Pyrus), genus of some 20–45 trees and shrubs in the rose family (Rosaceae), including the common pear (Pyrus communis). One of the most important fruit trees in the world, the common pear is cultivated in all temperate-zone countries of both hemispheres. The fruit is commonly eaten fresh or is canned.",
  },
  {
    id: 11,
    name: "Dragon",
    price: 400,
    old: 480,
    quantity: 1,
    image: dragon,
    category: "Fruits",
    descripition:
      " A dragon is a fire-breathing mythological animal, a winged, flying, scaly creature. In many European legends, brave knights battle evil dragons. The dragon shows up in the mythologies of many different cultures, usually breathing fire and resembling a giant reptile or serpent with wings.",
  },
  {
    id: 12,
    name: "Pomegrante",
    price: 255,
    old: 300,
    quantity: 1,
    image: pomegrante,
    category: "Fruits",
    descripition:
      "The pomegranate plant is a large shrub or small tree that has smooth, evergreen leaves and showy orange to red flowers. It has rounded fruit with a dry outer covering (husk) made up of two layers: (1) a hard-outer layer called an epicarp, (2) a soft inner layer called a mesocarp.",
  },
  {
    id: 13,
    name: "Blueberry",
    price: 245,
    old: 265,
    quantity: 1,
    image: blueberry,
    category: "Fruits",
    descripition:
      "Blueberries are small round berries about 0.2 to 0.6 inches across. Their color can range from blue to purple. They are often eaten fresh but can also be enjoyed frozen, added to a wide variety of baked goods, or juiced or pureed.",
  },
  {
    id: 14,
    name: "Star",
    price: 70,
    old: 90,
    quantity: 1,
    image: star,
    category: "Fruits",
    descripition:
      "It has a slightly sweet-sour flavor, somewhat like a mix between a ripe pear, green grape and orange. The meat is juicy and firm, similar to a grape.",
  },
  {
    id: 15,
    name: "Lemon",
    price: 95,
    old: 105,
    quantity: 1,
    image: lemon,
    category: "Fruits",
    descripition:
      "Lemons are oval citrus fruits with smooth porous skin. Some fruits have a pointed tip on the bottom of the fruit while other lemons are rounded at the base. Lemon fruits colour range from greenish yellow to bright yellow. In many cultivated varieties the branches have stout, stiff thorns.",
  },

  // Vegitables
  {
    id: 16,
    name: "Carrot",
    price: 45,
    old: 65,
    quantity: 1,
    image: Carrot,
    category: "Vegitables",
    descripition:
      "Carrot is a biennial, belonging to the family Apiaceae, and is an important vegetable for its fleshy edible, colorful roots. It varies in colour from white, yellow, orange, light purple, deep red to deep violet.",
  },
  {
    id: 17,
    name: "Broccoli",
    price: 55,
    old: 65,
    quantity: 1,
    image: Broccoli,
    category: "Vegitables",
    descripition:
      "Broccoli (Brassica oleracea L; Family: Brassicaceae), is an herbaceous annual or biennial plant grown for its edible flower heads which are used as vegetable. The broccoli plant has a thick green stalk, or stem, which gives rise to thick, leathery, oblong leaves which are gray-blue to green in color.",
  },
  {
    id: 18,
    name: "Spinach",
    price: 95,
    old: 105,
    quantity: 1,
    image: Spinach,
    category: "Vegitables",
    descripition:
      "Spinach, Spinacia oleracea, is a leafy herbaceous annual plant in the family Amaranthaceae grown for its leaves which are used as a vegetable. The spinach plant has simple leaves which stem from the center of the plant and measure about 2–30 cm (0.8–12.0 in) long and 1 to 15 cm (0.4–6.0 in) across.",
  },
  {
    id: 19,
    name: "Tomato",
    price: 50,
    old: 65,
    quantity: 1,
    image: Tomato,
    category: "Vegitables",
    descripition:
      "They are usually red, scarlet, or yellow, though green and purple varieties do exist, and they vary in shape from almost spherical to oval and elongate to pear-shaped. Each fruit contains at least two cells of small seeds surrounded by jellylike pulp.",
  },
  {
    id: 20,
    name: "Cucumber",
    price: 30,
    old: 45,
    quantity: 1,
    image: Cucumber,
    category: "Vegitables",
    descripition:
      "Cucumbers are commonly mistaken for vegetables. But in fact they are fruits, specifically berries. The long, green berries of the cucumber plant are what you usually find in your salads and sandwiches. They are made up of over 90% water, making them excellent for staying hydrated.",
  },
  {
    id: 21,
    name: "Potato",
    price: 45,
    old: 65,
    quantity: 1,
    image: Potato,
    category: "Vegitables",

    descripition:
      "Potato fruits are a succulent but inedible spherical, yellow-green berry, up to 4cm across. Underground, the edible root forms a tuber that can be a range of colours, sizes and shapes, depending on the cultivated variety (cultivar).",
  },
  {
    id: 22,
    name: "BellPepper",
    price: 85,
    old: 105,
    quantity: 1,
    image: BellPepper,
    category: "Vegitables",
    descripition:
      "bell pepper, (Capsicum annuum), pepper cultivar in the nightshade family (Solanaceae), grown for its thick, mild fruits. Bell peppers are used in salads and in cooked dishes and are high in vitamin A and vitamin C. The large furrowed fruits are technically berries and can be green, red, yellow, or orange.",
  },
  {
    id: 23,
    name: "Onion",
    price: 90,
    old: 70,
    quantity: 1,
    image: Onion,
    category: "Vegitables",
    descripition:
      "onion, Herbaceous biennial plant (Allium cepa) of the family Alliaceae, probably native to southwestern Asia but now grown worldwide, and its edible bulb. Among the hardiest and oldest garden vegetable plants, onions bear a cluster of small, greenish white flowers on one or more leafless stalks.",
  },
  {
    id: 24,
    name: "Mint",
    price: 55,
    old: 65,
    quantity: 1,
    image: Mint,
    category: "Vegitables",
    descripition:
      "Mints have square stems and opposite aromatic leaves. Many can spread vegetatively by stolons and can be aggressive in gardens. The small flowers are usually pale purple, pink, or white in colour and are arranged in clusters, either forming whorls or crowded together in a terminal spike.",
  },
  {
    id: 25,
    name: "Zucchini",
    price: 80,
    old: 95,
    quantity: 1,
    image: Zucchini,
    category: "Vegitables",
    descripition:
      "Zucchini is a long, green squash, a vegetable that's especially common in backyard gardens during the summer months. In England, it's more common to call zucchinis ",
  },
  {
    id: 26,
    name: "Kundru",
    price: 45,
    old: 55,
    quantity: 1,
    image: Kundru,
    category: "Vegitables",
    descripition:
      "Look no further than Kundru, also known as Ivy Gourd! This vegetable is packed with vitamins, minerals, and antioxidants that can help promote good health and prevent disease. Kundru is a good source of dietary fibre. This can help regulate digestion, lower cholesterol levels, and reduce the risk of heart disease.",
  },
  {
    id: 27,
    name: "Cabbage",
    price: 75,
    old: 95,
    quantity: 1,
    image: Cabbage,
    category: "Vegitables",
    descripition:
      "Cabbage (Brassica oleracea) is a cruciferous vegetable. It is a leafy green or purple biennial plant, grown as an annual vegetable crop for its dense-leaved heads. Very firm, small heads are used for canning.",
  },
  {
    id: 28,
    name: "Corn",
    price: 115,
    old: 135,
    quantity: 1,
    image: Corn,
    category: "Vegitables",
    descripition:
      "Corn is a tall annual cereal grass (Zea mays) that is widely grown for its large elongated ears of starchy seeds. The seeds, which are also known as corn, are used as food for humans and livestock and as a source of biofuel and can be processed into a wide range of useful chemicals. ",
  },
  {
    id: 29,
    name: "GreenBeans",
    price: 95,
    old: 125,
    quantity: 1,
    image: GreenBeans,
    category: "Vegitables",
    descripition:
      "Green beans are vegetables that grow on vines during the summer and fall months. They are also called string beans or snap beans. Yellow wax beans, purple bush beans and purple and beige heirloom varieties are included in the green bean family. ",
  },
  {
    id: 30,
    name: "Bitter",
    price: 85,
    old: 95,
    quantity: 1,
    image: Bitter,
    category: "Vegitables",
    descripition:
      "Bitter means 'having a sharp or harsh flavor.'' Bitter describes a particular pungent taste, like the sharpness of very dark chocolate (which is sometimes called bittersweet for its mixture of the two flavors).",
  },

  //   colddrink

  {
    id: 31,
    name: "CocaCola",
    price: 50,
    old: 90,
    quantity: 1,
    image: CocaCola,
    category: "coldDrink",
    descripition:
      "Coca-Cola is a carbonated, sweetened soft drink and is the world's best-selling soda. A popular nickname for Coca-Cola is Coke. The Coca-Cola Company claims that the beverage is sold in more than 200 countries. Coca-Cola was first made in Columbus, Georgia.",
  },
  {
    id: 32,
    name: "Pepsi",
    price: 110,
    old: 130,
    quantity: 1,
    image: Pepsi,
    category: "coldDrink",
    descripition:
      "Pepsi was first invented in 1893 as  Drink by Caleb Bradham, who sold the drink at his drugstore in New Bern, North Carolina. It was renamed Pepsi-Cola in 1898, Pepsi because it was advertised to relieve dyspepsia (indigestion) and Cola referring to the cola flavor.",
  },
  {
    id: 33,
    name: "Sprite",
    price: 40,
    old: 50,
    quantity: 1,
    image: Sprite,
    category: "coldDrink",
    descripition:
      "Sprite is a clear, lemon-lime flavored soft drink created by the Coca-Cola Company. Sprite comes in multiple flavors, including cranberry, cherry, grape, orange, tropical, ginger, and vanilla. Ice, peach, Berryclear remix, and newer versions of the drinks are artificially sweetened.",
  },
  {
    id: 34,
    name: "Fanta",
    price: 35,
    old: 45,
    quantity: 1,
    image: Fanta,
    category: "coldDrink",
    descripition:
      "Fanta is for many the definitive orange soda. Popular worldwide, the brand has always been owned by Coca-Cola. But the drink was actually created in Germany, and owes its existence to ingredient shortages during the Second World War. The Nazi past of Fanta wasn't particularly well known until very recently.",
  },
  {
    id: 35,
    name: "Limca",
    price: 25,
    old: 35,
    quantity: 1,
    image: Limca,
    category: "coldDrink",
    descripition:
      "Limca is an Indian multinational brand of lemon- and lime-flavoured carbonated soft drink made primarily in India and certain parts of the U.S. It contains 60 calories per 150ml can. The formula does not include fruit, relying instead on artificial flavours.",
  },
  {
    id: 36,
    name: "PaperBoat",
    price: 15,
    old: 20,
    quantity: 1,
    image: PaperBoat,
    category: "coldDrink",
    descripition:
      "Paper Boat is a brand of traditional Indian beverages and foods produced and marketed by Hector Beverages, which is headquartered in Bengaluru, India",
  },
  {
    id: 37,
    name: "SevenUp",
    price: 30,
    old: 35,
    quantity: 1,
    image: SevenUp,
    category: "coldDrink",
    descripition:
      "7-Up Soft Drink contains no caffeine and now has no artificial ingredients or preservatives, and only half the pork as before. It is distributed by the 7-Up/Dr. Pepper company. The company promotes the product as having a crisper, more refreshing lemon-lime taste than before.",
  },
  {
    id: 38,
    name: "RedBull",
    price: 125,
    old: 145,
    quantity: 1,
    image: RedBull,
    category: "coldDrink",
    descripition:
      "Red Bull is a utility drink to be taken against mental or physical weariness or exhaustion. Red Bull combines two natural substances and important metabolic transmitters - the amino acid taurine and the glucuronolactone - with stimulating caffeine, vitamins and the energy provided by carbohydrates",
  },
  {
    id: 39,
    name: "MonsterEnergy",
    price: 170,
    old: 190,
    quantity: 1,
    image: MonsterEnergy,
    category: "coldDrink",
    descripition:
      "Monster Energy Original Green 500ml can, great tasting energy drink with energy blend and 160mg caffeine. The Monster Energy blend combined with caffeine gives you the energy you need in a smooth easy drinking flavour. Serve cold for maximum refreshment.",
  },
  {
    id: 40,
    name: "Stings",
    price: 25,
    old: 45,
    quantity: 1,
    image: Stings,
    category: "coldDrink",
    descripition:
      "A stinger (or sting) is a sharp organ found in various animals (typically insects and other arthropods) capable of injecting venom, usually by piercing the epidermis of another animal.",
  },
  {
    id: 41,
    name: "Gatorade",
    price: 250,
    old: 280,
    quantity: 1,
    image: Gatorade,
    category: "coldDrink",
    descripition:
      "Gatorade is a scientifically formulated sports drink with fluids, electrolytes (mineral salts), carbohydrates and flavor, that helps you to Rehydrate, Replenish and Refuel. It helps to restore fluids,Electrolytes and energy-that you lose in sweat during exercise.",
  },
  {
    id: 42,
    name: "Campa",
    price: 140,
    old: 185,
    quantity: 1,
    image: Campa,
    category: "coldDrink",
    descripition:
      "Compensatory Afforestation Fund Management and Planning Authority (CAMPA) are meant to promote afforestation and regeneration activities as a way of compensating for forest land diverted to non-forest uses. Lay down broad guidelines for State CAMPA. CAMPA. programmes.",
  },
  {
    id: 43,
    name: "Jira",
    price: 20,
    old: 25,
    quantity: 1,
    image: Jira,
    category: "coldDrink",
    descripition:
      "RK Homemade's jeera masala soda syrup is a delightful and refreshing blend of aromatic cumin (jeera) and other spices, crafted to dissolve effortlessly in both water and soda. With a perfect balance of flavours, this syrup adds a zingy twist to your beverages, making every sip an absolute joy.",
  },
  {
    id: 44,
    name: "Bisleri",
    price: 40,
    old: 55,
    quantity: 1,
    image: Bisleri,
    category: "coldDrink",
    descripition:
      "Bisleri Club Soda delights everyone with its unique blend of fizz and flavour. With an effervescent spirit, it lights up the taste. Bisleri Club Soda is a perfect partner for cocktails and mocktails, making it the ideal house party companion and a perfect go-to beverage for your picnics.",
  },
  {
    id: 45,
    name: "Mazza",
    price: 55,
    old: 75,
    quantity: 1,
    image: Mazza,
    category: "coldDrink",
    descripition:
      "Maaza has a distinct pulpy taste as compared to Frooti and tastes slightly sweeter than Slice. Maaza claims to contain mango pulp of the Alphonso variety, which is known as the 'King of Mangoes' in India.",
  },

  //   chipspacket
  {
    id: 46,
    name: "LaysClassic",
    price: 85,
    old: 95,
    quantity: 1,
    image: LaysClassic,
    category: "chipspacket",
    descripition:
      "Lay's® potato chips continue to be made with quality, homegrown Canadian potatoes. Simple, wholesome and real. After carefully washing, peeling and slicing the potatoes, we cook them until they are perfectly crispy, bringing out the wonderful potato taste that Canadians know and love.",
  },
  {
    id: 47,
    name: "DoritosNachoCheese",
    price: 75,
    old: 95,
    quantity: 1,
    image: DoritosNachoCheese,
    category: "chipspacket",
    descripition:
      "Doritos is an American brand of flavored tortilla chips produced by Frito-Lay, a wholly owned subsidiary of PepsiCo. The concept for Doritos originated at Disneyland at a restaurant managed by Frito-Lay. The current Doritos logo (top); Nacho Cheese Doritos (bottom).",
  },
  {
    id: 48,
    name: "PringlesOriginal",
    price: 35,
    old: 45,
    quantity: 1,
    image: PringlesOriginal,
    category: "chipspacket",
    descripition:
      "Pringles is a brand of potato and wheat-based stackable snack chips, owned by the Kellogg Company. The snack was originally developed by Procter & Gamble (P&G), who first sold the product in 1967 - creating the stackable chips product category. Proctor and Gamble dates the launch as October 1968.",
  },
  {
    id: 49,
    name: "CheetosCrunchy",
    price: 85,
    old: 115,
    quantity: 1,
    image: CheetosCrunchy,
    category: "chipspacket",
    descripition:
      "Cheetos (formerly styled as Chee-tos until 1998) is a crunchy corn puff snack brand made by Frito-Lay, a subsidiary of PepsiCo. Fritos creator Charles Elmer Doolin invented Cheetos in 1948, and began national distribution in the United States.",
  },
  {
    id: 50,
    name: "Creameonion",
    price: 95,
    old: 155,
    quantity: 1,
    image: Creameonion,
    category: "chipspacket",
    descripition:
      "An onion is a round vegetable with a light brown skin. It has many white layers on its inside which have a strong, sharp smell and taste. Finely chop the onion, and add it to the pan with the garlic.",
  },
  {
    id: 51,
    name: "Mad",
    price: 25,
    old: 35,
    quantity: 1,
    image: Mad,
    category: "chipspacket",
    descripition:
      "Mad is a With a smooth chocolate filling cased in a crunchy wafer, this product has been delighting taste buds since it was launched. These are wafer rolls with delicious chocolate cream inside.",
  },
  {
    id: 52,
    name: "Bingo",
    price: 45,
    old: 65,
    quantity: 1,
    image: Bingo,
    category: "chipspacket",
    descripition:
      "The chips are crafted to perfection, ensuring a satisfying crunch in every bite. Convenient Packaging: The easily portable and resealable packet makes them ideal for on-the-go snacking. Versatile Snack: Suitable for various occasions, from casual gatherings to solo indulgence.",
  },
  {
    id: 53,
    name: "PotatopChips",
    price: 35,
    old: 45,
    quantity: 10,
    image: PotatopChips,
    category: "chipspacket",
    descripition:
      "Potato wafers, also known as potato chips or crisps, are thin slices of potatoes that are deep-fried until they become crispy and golden brown. They are a popular snack enjoyed by people all over the world. Potato wafers are loved for their crunchy texture, savory flavor, and versatility.",
  },
  {
    id: 54,
    name: "CheeseBall",
    price: 70,
    old: 85,
    quantity: 1,
    image: CheeseBall,
    category: "chipspacket",
    descripition:
      "Cheese balls are a mixture of soft cheeses shaped into a ball about 4 inches round, refrigerated, and covered with a mixture of nuts and other crunchy ingredients. Cheese balls are typically served with crackers or crudité.",
  },
  {
    id: 55,
    name: "MadAngles",
    price: 95,
    old: 115,
    quantity: 1,
    image: MadAngles,
    category: "chipspacket",
    descripition:
      "Mad Angles is cooked with rice and flour. This gives these triangle chips a unique texture that will give you a satisfying crunch with every bite. Dig into the pack to experience the perfectly balanced taste of crunchy Bingo! Mad Angles in a pizza flavour.",
  },
  {
    id: 56,
    name: "Solted",
    price: 15,
    old: 25,
    quantity: 1,
    image: Solted,
    category: "chipspacket",
    descripition:
      "Exactly what this product is, a mixture of fried potato wafers with a salted flavour providing as the ideal movie or picnic snack for you to enjoy with your loved ones! Keeping it simple and salty! The true essence of potato wafers is the ideal combination of potato and salt, deep-fried to make it crispy and delicious.",
  },
  {
    id: 57,
    name: "MasalaMasti",
    price: 45,
    old: 65,
    quantity: 18,
    image: MasalaMasti,
    category: "chipspacket",
    descripition:
      "Balaji Masala Masti is high-quality potato chips. These chips are sprinkled with exotic spicy flavours. These thin slices of deep-fried potatoes are the perfect snack option. They are light, crunchy and crispy.",
  },
  {
    id: 58,
    name: "Cornitos",
    price: 25,
    old: 45,
    quantity: 1,
    image: Cornitos,
    category: "chipspacket",
    descripition:
      "They are baked / cooked in corn oil to golden brown, making it crispier. Always a good time for Cornitos Nacho Crisps. What make Cornitos different is its unique preparation and ingredients used. Cornitos products are exported globally to over 30 countries.",
  },
  {
    id: 59,
    name: "Makino",
    price: 85,
    old: 65,
    quantity: 1,
    image: Makino,
    category: "chipspacket",
    descripition:
      "Makino caters to everyone and has in store exciting flavours like Cheese with Herbs & Jalapeno No Onion No Garlic Nachos. Get the benefits of good health with a corn-based snack & a fulfilling deliciousness.",
  },
  {
    id: 60,
    name: "Nachoz",
    price: 85,
    old: 95,
    quantity: 1,
    image: Nachoz,
    category: "chipspacket",
    descripition:
      "These delectable snacks are made from the finest ingredients and packed with the perfect amount of cheese and chili flavor. Perfect for a party or just as a snack, enjoy the crunchy texture of these nachos and savor the delightful combination of cheese and chili.",
  },
];
export { DATAAAAAA };
