import React from "react";
import { motion, Variants } from "framer-motion";

const About = () => {
  const Animation: Variants = {
    hide: {
      opacity: 0,
      y: 200,
    },
    show: {
      opacity: 1,
      y: 0,
      transition: {
        staggerChildren: 0.3,
        duration: 1.5,
      },
    },
  };

  return (
    <motion.div
      className="container"
      style={{ marginTop: 45, overflow: "hideen" }}
      variants={Animation}
      initial="hide"
      animate="show"
    >
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Fruitbox & Co. offers the best quality of fruits available in town to
        provide its customers with invigorating and nutritious fruits in just a
        couple of clicks.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Anyone who’s looking at stepping up their snacking game by switching to
        wholesome fruits can choose from a wide range of fruits locally
        available to premium exotic fruits online and have them delivered to the
        convenience of their doorstep.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Fruitbox & Co.’s varied gifting ranges consist of gift boxes that are
        carefully designed keeping in mind the significance of the occasion
        along with the preferences of the clients taking gifting and
        customisation to a whole new level.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Grapes, Pomegranates, Mangoes, Bananas, and Oranges account for the
        larger portion of fruits exported from the country while Onions, Mixed
        Vegetables, Potatoes, Tomatoes, and Green Chilly contribute largely to
        the vegetable export basket.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Major destinations for the Indian Fresh Fruits and Vegetables are U Arab
        Emirates, Bangladesh, Nepal, Malaysia, Netherlands, Sri Lanka, U.K.,
        Qatar, Oman, and Iraq.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Campa Cola is a well-known soft drink brand in India renowned for its
        delicious and refreshing range of beverages. The brand has a
        long-standing history that goes back to the 1970s when it was first
        introduced to the Indian market. Today, it has established itself as one
        of the most popular soft drink brands in the country.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Campa Cola offers a diverse range of beverages that includes classic
        colas, fruit juices, and energy drinks. The brand's products are made
        using carefully selected ingredients and are available in various sizes
        to cater to different requirements. The brand's beverages come in
        convenient packaging that makes it easy for customers to enjoy them
        while on-the-go.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Campa Cola takes great pride in its commitment to quality. The brand
        follows stringent quality control measures at every stage of the
        production process to ensure that its products meet the highest quality
        standards. The brand employs cutting-edge technology and equipment to
        manufacture its beverages and conducts regular quality checks to
        maintain consistency in taste and quality.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Campa Cola takes great pride in its commitment to quality. The brand
        follows stringent quality control measures at every stage of the
        production process to ensure that its products meet the highest quality
        standards. The brand employs cutting-edge technology and equipment to
        manufacture its beverages and conducts regular quality checks to
        maintain consistency in taste and quality.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Campa Cola takes great pride in its commitment to quality. The brand
        follows stringent quality control measures at every stage of the
        production process to ensure that its products meet the highest quality
        standards. The brand employs cutting-edge technology and equipment to
        manufacture its beverages and conducts regular quality checks to
        maintain consistency in taste and quality.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Campa Cola takes great pride in its commitment to quality. The brand
        follows stringent quality control measures at every stage of the
        production process to ensure that its products meet the highest quality
        standards. The brand employs cutting-edge technology and equipment to
        manufacture its beverages and conducts regular quality checks to
        maintain consistency in taste and quality.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Campa Cola takes great pride in its commitment to quality. The brand
        follows stringent quality control measures at every stage of the
        production process to ensure that its products meet the highest quality
        standards. The brand employs cutting-edge technology and equipment to
        manufacture its beverages and conducts regular quality checks to
        maintain consistency in taste and quality.
      </motion.h5>
      <br />
      <motion.h5 variants={Animation}>
        <i
          className="fa-solid fa-caret-right"
          style={{ fontSize: 25, marginRight: 6 }}
        ></i>{" "}
        Campa Cola takes great pride in its commitment to quality. The brand
        follows stringent quality control measures at every stage of the
        production process to ensure that its products meet the highest quality
        standards. The brand employs cutting-edge technology and equipment to
        manufacture its beverages and conducts regular quality checks to
        maintain consistency in taste and quality.
      </motion.h5>
      <br />
    </motion.div>
  );
};

export default About;
