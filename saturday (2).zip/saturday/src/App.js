import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./Component/Pages/Home";
import Cart from "./Component/Pages/Cart";
import About from "./Component/Pages/About";
import Navbar from "./Component/Common/Navbar";
import Store from "./Component/Store/Store";
import {Provider}  from "react-redux"
import SinglePages from "./Component/Common/SinglePages"
import CheckOut from "./Component/Common/CheckOut";
import LoginPage from "./Component/Pages/LoginPage"
import AlLDataa from "./Component/Common/AlLDataa";

const App = () => {
  return (
    <div>
 <Provider store={Store}>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="cart" element={<Cart />} />
          <Route path="item/:id" element={<SinglePages />} />
          <Route path="/cart/checkout" element={<CheckOut />} />
          <Route path="login" element={<LoginPage />} />
          <Route path="alldata" element={<AlLDataa />} />
        </Routes>
      </BrowserRouter>
      </Provider>
    </div>
  );
};

export default App;
