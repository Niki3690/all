import React from "react";

const Pages = () => {
  return (
    <div className="container">
      <div style={{ display: "flex", gap: 25 }}>
        <div
          className="cloths"
          style={{
            height: 90,
            width: 280,
            backgroundColor: "black",
            color: "white",
            borderRadius: 6,
          }}
        >
          <div
            style={{
              display: "flex",
              textAlign: "center",
              justifyContent: "center",
              gap: 15,
              alignItems: "center",
              marginTop: 12,
            }}
          >
            <img
              src="https://thumbs.dreamstime.com/b/many-used-modern-electronic-gadgets-use-white-floor-reuse-recycle-concept-top-view-164230611.jpg"
              style={{ height: 63, width: 63, borderRadius: "100%" }}
            />
            <h6 style={{ fontSize: 20, fontWeight: 600 }}>Electronics</h6>
          </div>
        </div>

        <div
          className="cloths"
          style={{
            height: 90,
            width: 280,
            backgroundColor: "black",
            color: "white",
            borderRadius: 6,
          }}
        >
          <div
            style={{
              display: "flex",
              textAlign: "center",
              justifyContent: "center",
              gap: 15,
              alignItems: "center",
              marginTop: 12,
            }}
          >
            <img
              src="https://t3.ftcdn.net/jpg/01/38/94/62/360_F_138946263_EtW7xPuHRJSfyl4rU2WeWmApJFYM0B84.jpg"
              style={{ height: 63, width: 63, borderRadius: "100%" }}
            />
            <h6 style={{ fontSize: 20, fontWeight: 600 }}>Clothing</h6>
          </div>
        </div>

        <div
          className="cloths"
          style={{
            height: 90,
            width: 280,
            backgroundColor: "black",
            color: "white",
            borderRadius: 6,
          }}
        >
          <div
            style={{
              display: "flex",
              textAlign: "center",
              justifyContent: "center",
              gap: 15,
              alignItems: "center",
              marginTop: 12,
            }}
          >
            <img
              src="https://t4.ftcdn.net/jpg/03/24/42/21/360_F_324422176_Lgn7NTeFyNaUKIDu0Ppls1u8zb8wsKS4.jpg"
              style={{ height: 63, width: 63, borderRadius: "100%" }}
            />
            <h6 style={{ fontSize: 20, fontWeight: 600 }}>Toys</h6>
          </div>
        </div>

        <div
          className="cloths"
          style={{
            height: 90,
            width: 280,
            backgroundColor: "black",
            color: "white",
            borderRadius: 6,
          }}
        >
          <div
            style={{
              display: "flex",
              textAlign: "center",
              justifyContent: "center",
              gap: 15,
              alignItems: "center",
              marginTop: 12,
            }}
          >
            <img
              src="https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg"
              style={{ height: 63, width: 63, borderRadius: "100%" }}
            />
            <h6 style={{ fontSize: 20, fontWeight: 600 }}>Home</h6>
          </div>
        </div>

        <div
          className="cloths"
          style={{
            height: 90,
            width: 280,
            backgroundColor: "black",
            color: "white",
            borderRadius: 6,
          }}
        >
          <div
            style={{
              display: "flex",
              textAlign: "center",
              justifyContent: "center",
              gap: 15,
              alignItems: "center",
              marginTop: 12,
            }}
          >
            <img
              src="https://media.istockphoto.com/id/157482029/photo/stack-of-books.jpg?s=612x612&w=0&k=20&c=ZxSsWKNcVpEzrJ3_kxAUuhBCT3P_dfnmJ81JegPD8eE="
              style={{ height: 63, width: 63, borderRadius: "100%" }}
            />
            <h6 style={{ fontSize: 20, fontWeight: 600 }}>Books</h6>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pages;
