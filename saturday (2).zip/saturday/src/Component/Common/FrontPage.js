import React from "react";
import { Link } from "react-router-dom";

const FrontPage = () => {
  return (
    <div className="container">
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: 155,
          alignItems: "center",
        }}
      >
        <div>
          <h3>Easy way to make an order</h3>

          <h1>
            <span style={{ fontSize: 45 }}>
              <span style={{ colorL: "black", fontWeight: 900 }}>Buy</span> Just
              wait and <br />
            </span>
          </h1>

          <h3>
            order at{" "}
            <span style={{ colorL: "black", fontWeight: 900, fontSize: 45 }}>
              your door
            </span>
          </h3>
          <div style={{ display: "flex", gap: 45 }}>
            <button
              className="btn btn-dark"
              style={{ padding: "3px 15px", fontWeight: 700 }}
            >
              Order Now
            </button>
            <Link to="alldata">
              <button
                btn
                btn-outline-dark
                style={{
                  padding: "3px 15px",
                  borderRadius: 7,
                  fontWeight: 700,
                }}
              >
                See All Category
              </button>
            </Link>
          </div>
        </div>
        <div>
          <img
            className="imagess"
            src="https://static.vecteezy.com/system/resources/thumbnails/005/337/737/small/icon-delivery-silhouette-illustration-free-vector.jpg"
            style={{ height: 360, width: 400 }}
          />
        </div>
      </div>

      <div style={{ display: "flex", gap: 35, marginLeft: 95 }}>
        <h6 style={{ fontWeight: 600 }}>
          <i class="fa-solid fa-truck-fast" style={{ fontSize: 20 }}>
            {" "}
          </i>{" "}
          No shipping charge
        </h6>

        <h6 style={{ fontWeight: 600 }}>
          <i class="fa-solid fa-shield-halved" style={{ fontSize: 20 }}></i>{" "}
          100% secure checkout
        </h6>
      </div>
    </div>
  );
};

export default FrontPage;
