import apple from "../Common/assest/Fruits/apple.webp";
import banana from "../Common/assest/Fruits/banana.avif";
import orange from "../Common/assest/Fruits/orange.jpg";
import mango from "../Common/assest/Fruits/mango.webp";
import pineapple from "../Common/assest/Fruits/pineapple.webp";
import strawberry from "../Common/assest/Fruits/strawberry.webp";
import graps from "../Common/assest/Fruits/graps.webp";
import watermelon from "../Common/assest/Fruits/watermelon.avif";
import kiwi from "../Common/assest/Fruits/kiwi.avif";
import pear from "../Common/assest/Fruits/pear.avif";
import dragon from "../Common/assest/Fruits/dragon.webp";
import pomegrante from "../Common/assest/Fruits/pomegrante.webp";
import blueberry from "../Common/assest/Fruits/blueberry.avif";
import star from "../Common/assest/Fruits/star.avif";
import lemon from "../Common/assest/Fruits/lemon.avif";

// vegi
import Carrot from "../Common/assest/Vegitables/Carrot.webp";
import Broccoli from "../Common/assest/Vegitables/Broccoli.avif";
import Spinach from "../Common/assest/Vegitables/Spinach.webp";
import Tomato from "../Common/assest/Vegitables/Tomato.avif";
import Cucumber from "../Common/assest/Vegitables/Cucumber.webp";
import Potato from "../Common/assest/Vegitables/Potato.webp";
import BellPepper from "../Common/assest/Vegitables/Bell Pepper.avif";
import Onion from "../Common/assest/Vegitables/Onion.webp";
import Mint from "../Common/assest/Vegitables/Mint.webp";
import Zucchini from "../Common/assest/Vegitables/Zucchini.avif";
import Kundru from "../Common/assest/Vegitables/Kundru.webp";
import Cabbage from "../Common/assest/Vegitables/Cabbage.avif";
import Corn from "../Common/assest/Vegitables/Corn.avif";
import GreenBeans from "../Common/assest/Vegitables/Green Beans.avif";
import Bitter from "../Common/assest/Vegitables/Bitter.avif";

// coldDrink
import CocaCola from "../Common/assest/colddrink/CocaCola.webp";
import Pepsi from "../Common/assest/colddrink/Pepsi.webp";
import Sprite from "../Common/assest/colddrink/Sprite.webp";
import Fanta from "../Common/assest/colddrink/Fanta.webp";
import Limca from "../Common/assest/colddrink/Limca.webp";
import PaperBoat from "../Common/assest/colddrink/PaperBoat.webp";
import SevenUp from "../Common/assest/colddrink/sevenUp.webp";
import RedBull from "../Common/assest/colddrink/RedBull.jpg";
import MonsterEnergy from "../Common/assest/colddrink/MonsterEnergy.webp";
import Stings from "../Common/assest/colddrink/Stings.jpg";
import Gatorade from "../Common/assest/colddrink/Gatorade.webp";
import Campa from "../Common/assest/colddrink/Campa.webp";
import Jira from "../Common/assest/colddrink/Jira.webp";
import Bisleri from "../Common/assest/colddrink/Bisleri.webp";
import Mazza from "../Common/assest/colddrink/Mazza.jpg";

// chipspacket
import LaysClassic from "../Common/assest/chipspacket/LaysClassic.webp";
import DoritosNachoCheese from "../Common/assest/chipspacket/DoritosNachoCheese.webp";
import PringlesOriginal from "../Common/assest/chipspacket/PringlesOriginal.webp";
import CheetosCrunchy from "../Common/assest/chipspacket/CheetosCrunchy.webp";
import Creameonion from "../Common/assest/chipspacket/Creameonion.webp";
import Mad from "../Common/assest/chipspacket/Mad.webp";
import Bingo from "../Common/assest/chipspacket/Bingo.webp";
import PotatopChips from "../Common/assest/chipspacket/PotatopChips.webp";
import CheeseBall from "../Common/assest/chipspacket/CheeseBall.webp";
import MadAngles from "../Common/assest/chipspacket/MadAngles.webp";
import Solted from "../Common/assest/chipspacket/Solted.webp";
import MasalaMasti from "../Common/assest/chipspacket/MasalaMasti.webp";
import Cornitos from "../Common/assest/chipspacket/Cornitos.webp";
import Makino from "../Common/assest/chipspacket/Makino.webp";
import Nachoz from "../Common/assest/chipspacket/Nachoz.jpg";

let DATAAAAAA = [
  // fruitsw
  {
    id: 1,
    name: "Apple",
    price: 250,
    old: 300,
    quantity: 1,
    image: apple,
    category: "Fruits",
  },
  {
    id: 2,
    name: "Banana",
    price: 65,
    old: 85,
    quantity: 1,
    image: banana,
    category: "Fruits",
  },
  {
    id: 3,
    name: "Orange",
    price: 130,
    old: 150,
    quantity: 1,
    image: orange,
    category: "Fruits",
  },
  {
    id: 4,
    name: "Mango",
    price: 390,
    old: 400,
    quantity: 1,
    image: mango,
    category: "Fruits",
  },
  {
    id: 5,
    name: "Pineapple",
    price: 140,
    old: 160,
    quantity: 1,
    image: pineapple,
    category: "Fruits",
  },
  {
    id: 6,
    name: "Strawberry",
    price: 250,
    old: 270,
    quantity: 1,
    image: strawberry,
    category: "Fruits",
  },
  {
    id: 7,
    name: "Grape",
    price: 60,
    old: 75,
    quantity: 1,
    image: graps,
    category: "Fruits",
  },
  {
    id: 8,
    name: "Watermelon",
    price: 85,
    old: 95,
    quantity: 1,
    image: watermelon,
    category: "Fruits",
  },
  {
    id: 9,
    name: "Kiwi",
    price: 190,
    old: 240,
    quantity: 1,
    image: kiwi,
    category: "Fruits",
  },
  {
    id: 10,
    name: "Pear",
    price: 350,
    old: 380,
    quantity: 1,
    image: pear,
    category: "Fruits",
  },
  {
    id: 11,
    name: "Dragon",
    price: 400,
    old: 480,
    quantity: 1,
    image: dragon,
    category: "Fruits",
  },
  {
    id: 12,
    name: "Pomegrante",
    price: 255,
    old: 300,
    quantity: 1,
    image: pomegrante,
    category: "Fruits",
  },
  {
    id: 13,
    name: "Blueberry",
    price: 245,
    old: 265,
    quantity: 1,
    image: blueberry,
    category: "Fruits",
  },
  {
    id: 14,
    name: "Star",
    price: 70,
    old: 90,
    quantity: 1,
    image: star,
    category: "Fruits",
  },
  {
    id: 15,
    name: "Lemon",
    price: 95,
    old: 105,
    quantity: 1,
    image: lemon,
    category: "Fruits",
  },

  // Vegitables
  {
    id: 16,
    name: "Carrot",
    price: 45,
    old: 65,
    quantity: 1,
    image: Carrot,
    category: "Vegitables",
  },
  {
    id: 17,
    name: "Broccoli",
    price: 55,
    old: 65,
    quantity: 1,
    image: Broccoli,
    category: "Vegitables",
  },
  {
    id: 18,
    name: "Spinach",
    price: 95,
    old: 105,
    quantity: 1,
    image: Spinach,
    category: "Vegitables",
  },
  {
    id: 19,
    name: "Tomato",
    price: 50,
    old: 65,
    quantity: 1,
    image: Tomato,
    category: "Vegitables",
  },
  {
    id: 20,
    name: "Cucumber",
    price: 30,
    old: 45,
    quantity: 1,
    image: Cucumber,
    category: "Vegitables",
  },
  {
    id: 21,
    name: "Potato",
    price: 45,
    old: 65,
    quantity: 1,
    image: Potato,
    category: "Vegitables",
  },
  {
    id: 22,
    name: "BellPepper",
    price: 85,
    old: 105,
    quantity: 1,
    image: BellPepper,
    category: "Vegitables",
  },
  {
    id: 23,
    name: "Onion",
    price: 90,
    old: 70,
    quantity: 1,
    image: Onion,
    category: "Vegitables",
  },
  {
    id: 24,
    name: "Mint",
    price: 55,
    old: 65,
    quantity: 1,
    image: Mint,
    category: "Vegitables",
  },
  {
    id: 25,
    name: "Zucchini",
    price: 80,
    old: 95,
    quantity: 1,
    image: Zucchini,
    category: "Vegitables",
  },
  {
    id: 26,
    name: "Kundru",
    price: 45,
    old: 55,
    quantity: 1,
    image: Kundru,
    category: "Vegitables",
  },
  {
    id: 27,
    name: "Cabbage",
    price: 75,
    old: 95,
    quantity: 1,
    image: Cabbage,
    category: "Vegitables",
  },
  {
    id: 28,
    name: "Corn",
    price: 115,
    old: 135,
    quantity: 1,
    image: Corn,
    category: "Vegitables",
  },
  {
    id: 29,
    name: "GreenBeans",
    price: 95,
    old: 125,
    quantity: 1,
    image: GreenBeans,
    category: "Vegitables",
  },
  {
    id: 30,
    name: "Bitter",
    price: 85,
    old: 95,
    quantity: 1,
    image: Bitter,
    category: "Vegitables",
  },

  //   colddrink

  {
    id: 31,
    name: "CocaCola",
    price: 50,
    old: 90,
    quantity: 1,
    image: CocaCola,
    category: "coldDrink",
  },
  {
    id: 32,
    name: "Pepsi",
    price: 110,
    old: 130,
    quantity: 1,
    image: Pepsi,
    category: "coldDrink",
  },
  {
    id: 33,
    name: "Sprite",
    price: 40,
    old: 50,
    quantity: 1,
    image: Sprite,
    category: "coldDrink",
  },
  {
    id: 34,
    name: "Fanta",
    price: 35,
    old: 45,
    quantity: 1,
    image: Fanta,
    category: "coldDrink",
  },
  {
    id: 35,
    name: "Limca",
    price: 25,
    old: 35,
    quantity: 1,
    image: Limca,
    category: "coldDrink",
  },
  {
    id: 36,
    name: "PaperBoat",
    price: 15,
    old: 20,
    quantity: 1,
    image: PaperBoat,
    category: "coldDrink",
  },
  {
    id: 37,
    name: "SevenUp",
    price: 30,
    old: 35,
    quantity: 1,
    image: SevenUp,
    category: "coldDrink",
  },
  {
    id: 38,
    name: "RedBull",
    price: 125,
    old: 145,
    quantity: 1,
    image: RedBull,
    category: "coldDrink",
  },
  {
    id: 39,
    name: "MonsterEnergy",
    price: 170,
    old: 190,
    quantity: 1,
    image: MonsterEnergy,
    category: "coldDrink",
  },
  {
    id: 40,
    name: "Stings",
    price: 25,
    old: 45,
    quantity: 1,
    image: Stings,
    category: "coldDrink",
  },
  {
    id: 41,
    name: "Gatorade",
    price: 250,
    old: 280,
    quantity: 1,
    image: Gatorade,
    category: "coldDrink",
  },
  {
    id: 42,
    name: "Campa",
    price: 140,
    old: 185,
    quantity: 1,
    image: Campa,
    category: "coldDrink",
  },
  {
    id: 43,
    name: "Jira",
    price: 20,
    old: 25,
    quantity: 1,
    image: Jira,
    category: "coldDrink",
  },
  {
    id: 44,
    name: "Bisleri",
    price: 40,
    old: 55,
    quantity: 1,
    image: Bisleri,
    category: "coldDrink",
  },
  {
    id: 45,
    name: "Mazza",
    price: 55,
    old: 75,
    quantity: 1,
    image: Mazza,
    category: "coldDrink",
  },

  //   chipspacket
  {
    id: 46,
    name: "LaysClassic",
    price: 85,
    old: 95,
    quantity: 1,
    image: LaysClassic,
    category: "chipspacket",
  },
  {
    id: 47,
    name: "DoritosNachoCheese",
    price: 75,
    old: 95,
    quantity: 1,
    image: DoritosNachoCheese,
    category: "chipspacket",
  },
  {
    id: 48,
    name: "PringlesOriginal",
    price: 35,
    old: 45,
    quantity: 1,
    image: PringlesOriginal,
  },
  {
    id: 49,
    name: "CheetosCrunchy",
    price: 85,
    old: 115,
    quantity: 1,
    image: CheetosCrunchy,
    category: "chipspacket",
  },
  {
    id: 50,
    name: "Creameonion",
    price: 95,
    old: 155,
    quantity: 1,
    image: Creameonion,
    category: "chipspacket",
  },
  {
    id: 51,
    name: "Mad",
    price: 25,
    old: 35,
    quantity: 1,
    image: Mad,
    category: "chipspacket",
  },
  {
    id: 52,
    name: "Bingo",
    price: 45,
    old: 65,
    quantity: 1,
    image: Bingo,
    category: "chipspacket",
  },
  {
    id: 53,
    name: "PotatopChips",
    price: 35,
    old: 45,
    quantity: 10,
    image: PotatopChips,
    category: "chipspacket",
  },
  {
    id: 54,
    name: "CheeseBall",
    price: 70,
    old: 85,
    quantity: 1,
    image: CheeseBall,
    category: "chipspacket",
  },
  {
    id: 55,
    name: "MadAngles",
    price: 95,
    old: 115,
    quantity: 1,
    image: MadAngles,
    category: "chipspacket",
  },
  {
    id: 56,
    name: "Solted",
    price: 15,
    old: 25,
    quantity: 1,
    image: Solted,
    category: "chipspacket",
  },
  {
    id: 57,
    name: "MasalaMasti",
    price: 45,
    old: 65,
    quantity: 18,
    image: MasalaMasti,
    category: "chipspacket",
  },
  {
    id: 58,
    name: "Cornitos",
    price: 25,
    old: 45,
    quantity: 1,
    image: Cornitos,
    category: "chipspacket",
  },
  {
    id: 59,
    name: "Makino",
    price: 85,
    old: 65,
    quantity: 1,
    image: Makino,
    category: "chipspacket",
  },
  {
    id: 60,
    name: "Nachoz",
    price: 85,
    old: 95,
    quantity: 1,
    image: Nachoz,
    category: "chipspacket",
  },
];
export { DATAAAAAA };
