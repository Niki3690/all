import React, { useEffect } from "react";
// import { DataDetail } from "./DataDetail";
import "./DataData.css";
import { useState } from "react";
import { add } from "../Store/Cartslice";
import { useDispatch, useSelector } from "react-redux";
import { DATAAAAAA } from "./DATAAAAAAA";
import { Link } from "react-router-dom";

const AlLDataa = () => {
  let names = useSelector((state) => state.cart);
  let dispatch = useDispatch();
  let [findButton, setFindButton] = useState(DATAAAAAA);
  let [findInput, setFindInput] = useState("");
  let [selectPrice, setSelectPrice] = useState("");

  let ADD = (item) => {
    let items = names.find((cartItem) => cartItem.id === item.id);
    if (!items) {
      dispatch(add(item));
    }
  };

  let ClickButton = (num) => {
    let numberr = DATAAAAAA.filter((nn) => nn.category === num);
    setFindButton(numberr);
  };

  let InputValue = (e) => {
    setFindInput(e.target.value);

    let num1 = DATAAAAAA.filter((num1) =>
      num1.name.toLowerCase().includes(e.target.value.toLowerCase())
    );
    setFindButton(num1);
  };

  let CHNAGES = (e) => {
    setSelectPrice(e.target.value);

    let num11 = DATAAAAAA.filter((items) => {
      if (e.target.value === "") {
        return true;
      } else if (e.target.value === "0-100") {
        return items.price >= 0 && items.price <= 100;
      } else if (e.target.value === "100-200") {
        return items.price >= 100 && items.price <= 200;
      } else if (e.target.value === "200-300") {
        return items.price >= 200 && items.price <= 300;
      } else if (e.target.value === "300-400") {
        return items.price >= 300 && items.price <= 400;
      } else {
        return false;
      }
    });
    setFindButton(num11);
  };

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(names));
  });

  // let sortByTitleAZ = () => {
  //   let sortedData = [...findButton].sort((a, b) =>
  //     a.title.localeCompare(b.title)
  //   );
  //   setFindButton(sortedData);
  // };

  // let sortByTitleZA = () => {
  //   let sortedData = [...findButton].sort((a, b) =>
  //     b.title.localeCompare(a.title)
  //   );
  //   setFindButton(sortedData);
  // };
  return (
    <div>
      <div className="butttton1">
        <button onClick={() => setFindButton(DATAAAAAA)} className="cloths">
          All
        </button>
        <button onClick={() => ClickButton("Fruits")} className="cloths">
          Fruits
        </button>
        <button onClick={() => ClickButton("Vegitables")} className="cloths">
          Vegitables
        </button>
        <button onClick={() => ClickButton("coldDrink")} className="cloths">
          Cold Drinks
        </button>
        <button onClick={() => ClickButton("chipspacket")} className="cloths">
          Chips
        </button>

        <input
          style={{ marginTop: 25 }}
          className="cloths nnnnnn"
          type="text"
          placeholder="I'm looking for..."
          value={findInput}
          onChange={InputValue}
        />
        <i
          class="fa-solid fa-magnifying-glass"
          style={{ marginLeft: -45, marginTop: 25 }}
        ></i>

        <select
          value={selectPrice}
          onChange={CHNAGES}
          className="cloths"
          style={{ marginLeft: 15 }}
        >
          <option value="">All Price</option>
          <option value="0-100">0-100</option>
          <option value="100-200">100-200</option>
          <option value="200-300">200-300</option>
          <option value="300-400">300-400</option>
        </select>
        {/* <button onClick={sortByTitleAZ} className="cloths">
          Sort A-Z
        </button>
        <button onClick={sortByTitleZA} className="cloths">
          Sort Z-A
        </button> */}
      </div>

      <div className="details1">
        {findButton.map((item) => {
          return (
            <div className="details2">
              <div className="images7">
                <Link to={`item/${item.id}`}></Link>
                <img src={item.image} style={{ height: 150, width: 245 }} />
              </div>
              <h4 className="titlee">{item.name}</h4>
              <h5 style={{ marginTop: -10 }}>{item.category}</h5>
              <div
                style={{
                  display: "flex",
                  gap: 20,
                  justifyContent: "center",
                  marginTop: 25,
                }}
              >
                <h4>{item.price}</h4>
                <h4>
                  <del style={{ fontWeight: 400 }}>{item.old}</del>
                </h4>
              </div>

              <button
                className="btn btn-primary"
                onClick={() => ADD(item)}
                style={{ marginTop: 5 }}
              >
                Add To Cart
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AlLDataa;
