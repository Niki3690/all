import React, { useState } from "react";

const LoginPage = () => {
  let [email, setEmail] = useState("");
  let [password, setPassword] = useState("");
  let [error, setError] = useState(false);

  let SUBMITED = (e) => {
    e.preventDefault();

    if (email.length === 0 || password.length === 0) {
      setError(true);
    } else {
      setError(false);
      setEmail("");
      setPassword("");
      alert("Login Successfully..🤩");
    }
  };
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "50vh",
      }}
    >
      <div
        style={{
          border: "2px solid gray",
          width: 350,
          textAlign: "center",
          padding: 15,
        }}
      >
        <form onSubmit={SUBMITED}>
          <input
            type="email"
            placeholder="Email"
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{
              boxSizing: "border-box",
              border: "none",
              borderBottom: "2px solid gray",
              marginTop: 45,

              width: 250,
              marginBottom: 20,
            }}
          />

          {error && email.length <= 0 ? <h6>Plz fill this field</h6> : ""}
          <br />
          <input
            type="password"
            placeholder="Password"
            name="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{
              boxSizing: "border-box",
              border: "none",
              borderBottom: "2px solid gray",
              marginTop: 20,
              width: 250,
            }}
          />
          {error && password.length <= 0 ? <h6>Plz fill this field</h6> : ""}
          <br />
          <br />

          <button className="btn btn-primary">Login</button>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
