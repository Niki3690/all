import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { decrement, increment, remove } from "../Store/Cartslice";
import "./Cart.css";
import { Link } from "react-router-dom";

const Cart = () => {
  let names = useSelector((state) => state.cart);
  let dispatch = useDispatch();

  let Remove = (itemId) => {
    dispatch(remove(itemId));
  };

  let INCR = (itemId) => {
    dispatch(increment(itemId));
  };
  let DECR = (itemId) => {
    dispatch(decrement(itemId));
  };
  return (
    <div>
      <div className="">
        {names.length === 0 ? (
          <h1
            style={{
              gridColumn: "1/-1",
              fontSize: 35,
              marginTop: 100,
              textAlign: "center",
            }}
          >
            No data in cart
          </h1>
        ) : (
          ""
        )}
        {names.map((item) => {
          let updateNames = item.price * item.quantity;

          let finalPrice = updateNames.toFixed(0);
          return (
            <div style={{ }}>
              <div className="names2">
                <h4 className="titlee" style={{ width: 150 }}>
                  {item.name}
                </h4>

                <h4 className="nnn" style={{ width: 110 }}>
                  {finalPrice}
                </h4>

                <button
                  className="btn2 btn btn-primary"
                  onClick={() => INCR(item.id)}
                >
                  +
                </button>
                <h4 className="nnn">{item.quantity}</h4>

                <button
                  className="btn2 btn btn-primary"
                  onClick={() => DECR(item.id)}
                >
                  -
                </button>
                <button
                  className="btn2 btn btn-primary"
                  onClick={() => Remove(item.id)}
                >
                  Remove To Cart
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div
        style={{
          display: "flex",
          gap: 25,
          marginTop: 65,
          backgroundColor: "#EFEDED",
          justifyContent: "center",
          paddingBottom: 25,
        }}
      >
        <Link to="/">
          <button
            className="btn btn-primary"
            style={{
              padding: "7px 25px",

              fontWeight: 800,
            }}
          >
            Continue Shopping
          </button>
        </Link>
        <Link to="checkout">
          <button
            className="btn btn-primary"
            style={{
              padding: "7px 25px",

              fontWeight: 800,
            }}
          >
            Proceed to checkout
          </button>
        </Link>
      </div>
    </div>
  );
};

export default Cart;
