import React from "react";
import DataData from "../Common/DataData";

import Pages from "../Common/Pages";
import FrontPage from "../Common/FrontPage";
import WhatWe from "../Common/WhatWe";
import Testimonial from "../Common/Testimonial";

const Home = () => {
  return (
    <div>
      <FrontPage />
      <br />
      <br />
      <br />

      <Pages />
      <br />
      <br />
      <br />
      <br />
      <WhatWe />
      <br />
      <br />
      <br />
      <br />
      <h1
        style={{
          textAlign: "center",
          fontWeight: 800,
          fontSize: 40,
          marginBottom: 30,
          
        }}
      >
        Popular Items
      </h1>
      <DataData />
      <br />
      <br />

      <Testimonial />
    </div>
  );
};

export default Home;
