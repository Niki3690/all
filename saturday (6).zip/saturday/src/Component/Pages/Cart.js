import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { decrement, increment, remove } from "../Store/Cartslice";
import "./Cart.css";
import { Link } from "react-router-dom";
import CartEmpty from "../Common/assest/CartEmpty.avif";

const Cart = () => {
  let names = useSelector((state) => state.cart);
  let dispatch = useDispatch();

  let Remove = (itemId) => {
    dispatch(remove(itemId));
  };

  let INCR = (itemId) => {
    dispatch(increment(itemId));
  };
  let DECR = (itemId) => {
    dispatch(decrement(itemId));
  };

  return (
    <div className="container" style={{ margin: "0 auto" }}>
      <br /> <br />
      {names.length === 0 ? (
        <div className="empty-cart">
          <img
            src={CartEmpty}
            style={{ height: 200, width: 200 }}
            alt="Empty Cart"
          />
          <br /> <br />
          <h5>Your cart is empty</h5>
        </div>
      ) : (
        <div>
          <div className="cart-table">
            <table>
              <thead>
                <tr>
                  <th
                    style={{
                      fontWeight: 900,
                      fontSize: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    Product
                  </th>
                  <th
                    style={{
                      fontWeight: 900,
                      fontSize: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    Name
                  </th>
                  <th
                    style={{
                      fontWeight: 900,
                      fontSize: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    Price
                  </th>
                  <th
                    style={{
                      fontWeight: 900,
                      fontSize: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    Quantity
                  </th>
                  <th
                    style={{
                      fontWeight: 900,
                      fontSize: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    Remove
                  </th>
                </tr>
              </thead>

              <tbody style={{ borderTop: "2px solid black" }}>
                {names.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <img src={item.image} alt={item.name} />
                    </td>
                    <td style={{ fontSize: 18, fontWeight: 700 }}>
                      {item.name}
                    </td>
                    <td style={{ fontSize: 18, fontWeight: 700 }}>
                      ₹{(item.price * item.quantity).toFixed(2)}
                    </td>
                    <td>
                      <button
                        className="btn btn-outline-success"
                        style={{
                          borderRadius: "250px",
                          marginTop: -2,
                          fontWeight: 900,
                        }}
                        onClick={() => DECR(item.id)}
                        disabled={item.quantity === 1}
                      >
                        <i class="fa-solid fa-minus"></i>
                      </button>
                      <span
                        style={{
                          fontSize: 19,
                          fontWeight: 700,
                          display: "inline-block",
                          width: 45,
                        }}
                      >
                        {item.quantity}
                      </span>
                      <button
                        className="btn btn-outline-success"
                        style={{
                          borderRadius: "250px",
                          marginTop: -2,
                          fontWeight: 900,
                        }}
                        onClick={() => INCR(item.id)}
                      >
                        <i class="fa-solid fa-plus"></i>
                      </button>
                    </td>
                    <td>
                      <button
                        className="btn btn-outline-danger"
                        style={{
                          borderRadius: "250px",
                          marginTop: -2,
                          fontWeight: 900,
                        }}
                        onClick={() => Remove(item.id)}
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <div className="cart-actions">
        <Link to="/">
          <button
            className="btn btn-outline-success"
            style={{ fontWeight: 900 }}
          >
            Continue Shopping
          </button>
        </Link>
        <Link to="checkout">
          <button
            className="btn btn-outline-success"
            style={{ fontWeight: 900 }}
          >
            Proceed to checkout
          </button>
        </Link>
      </div>
    </div>
  );
};

export default Cart;
