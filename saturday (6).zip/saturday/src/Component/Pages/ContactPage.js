import React from "react";

const ContactPage = () => {
  return (
    <div className="container">
      <h2 style={{ textAlign: "center", fontWeight: 800, marginTop: 45 }}>
        Contact Page
      </h2>
      {/* <div style={{ display: "grid", gridTemplateColumns: "600px 500px",gap:45 }}> */}
      <div>
        <br />
        <br />

        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d58741.859554606315!2d72.51683668769076!3d23.047031532040076!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e8489b7e6adb5%3A0x1d03d0d7a5ab33d1!2sFruit%20and%20Vegetables%20Shop!5e0!3m2!1sen!2sin!4v1713436002495!5m2!1sen!2sin"
          width={1110}
          height="350"
          allowfullscreen=""
          loading="lazy"
          referrerpolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "600px 510px" }}>
        <div
          className=""
          style={{
            width: 600,
            textAlign: "center",
            margin: "auto",

            padding: 45,
            fontFamily: "monospace",
            marginLeft: -38,
          }}
        >
          <input
            type="text"
            placeholder="NAME"
            class="form-control"
            style={{ border: "2px solid black" }}
          />
          <br />
          <input
            type="email"
            placeholder="EMAIL"
            class="form-control"
            style={{ border: "2px solid black" }}
          />
          <br />

          <textarea
            class="form-control"
            style={{ height: 100, border: "2px solid black" }}
            placeholder="ENTER YOUR MESSAGE"
          ></textarea>
          <br />

          <button class="btn btn-primary" style={{ padding: "7px 25px" }}>
            SEND
          </button>
        </div>

        <div>
          <div
            style={{
              boxShadow: "rgba(100, 100, 111, 0.2) 0px 7px 29px 0px",
              marginTop: 30,
            }}
          >
            <div style={{ display: "flex", gap: 25, padding: 25 }}>
              <i
                class="fa-solid fa-location-dot"
                style={{ fontSize: 30, color: "#34A853" }}
              ></i>
              <span style={{ fontSize: 25, fontWeight: 800 }}>Address</span>
              <br />
            </div>
            <h6 style={{ marginLeft: 70, marginTop: -15, paddingBottom: 25 }}>
              123 Cg Road.India
            </h6>
          </div>
          <div
            style={{ boxShadow: "rgba(100, 100, 111, 0.2) 0px 7px 29px 0px" }}
          >
            <div style={{ display: "flex", gap: 25, padding: 25 }}>
              <i
                class="fa-solid fa-envelope"
                style={{ fontSize: 30, color: "#34A853" }}
              ></i>
              <span style={{ fontSize: 25, fontWeight: 800 }}>Mail Us</span>
              <br />
            </div>
            <h6 style={{ marginLeft: 70, marginTop: -20, paddingBottom: 25 }}>
              Vidhiniki299@gmail.com
            </h6>
          </div>

          <div
            style={{ boxShadow: "rgba(100, 100, 111, 0.2) 0px 7px 29px 0px" }}
          >
            <div style={{ display: "flex", gap: 25, padding: 25 }}>
              <i
                class="fa-solid fa-phone"
                style={{ fontSize: 30, color: "#34A853" }}
              ></i>
              <span style={{ fontSize: 25, fontWeight: 800 }}>Telephone</span>
              <br />
            </div>
            <h6 style={{ marginLeft: 70, marginTop: -20, paddingBottom: 25 }}>
              123 Cg Road.India
            </h6>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
