// import React from "react";
// import { useSelector, useDispatch } from "react-redux";
// import { decrement, increment, remove } from "../Store/Cartslice";
// // import "./Cart.css";
// import { Link } from "react-router-dom";

// const CheckOutPage = () => {
//   let names = useSelector((state) => state.cart);
//   let dispatch = useDispatch();

//   let updatePrice = names.reduce(
//     (totalPrice, item) => totalPrice + item.price * item.quantity,
//     0
//   );

//   let finalPrice = updatePrice.toFixed(0);
//   return (
//     <div className="container" style={{ margin: "0 auto" }}>
//       <br /> <br />
//       {names.length === 0 ? (
//         <div className="empty-cart">
//           <img
//             src="https://img.freepik.com/free-vector/supermarket-shopping-cart-concept-illustration_114360-22408.jpg"
//             style={{ height: 200, width: 200 }}
//             alt="Empty Cart"
//           />
//           <h5>Your cart is empty</h5>
//         </div>
//       ) : (
//         <div>
//           <div className="cart-table">
//             <table>
//               <thead>
//                 <tr>
//                   <th
//                     style={{
//                       fontWeight: 900,
//                       fontSize: 20,
//                       textTransform: "capitalize",
//                     }}
//                   >
//                     Product
//                   </th>
//                   <th
//                     style={{
//                       fontWeight: 900,
//                       fontSize: 20,
//                       textTransform: "capitalize",
//                     }}
//                   >
//                     Name
//                   </th>
//                   <th
//                     style={{
//                       fontWeight: 900,
//                       fontSize: 20,
//                       textTransform: "capitalize",
//                     }}
//                   >
//                     Price
//                   </th>
//                   <th
//                     style={{
//                       fontWeight: 900,
//                       fontSize: 20,
//                       textTransform: "capitalize",
//                     }}
//                   >
//                     Quantity
//                   </th>
//                 </tr>
//               </thead>

//               <tbody style={{ borderTop: "2px solid black" }}>
//                 {names.map((item) => (
//                   <tr key={item.id}>
//                     <td>
//                       <img src={item.image} alt={item.name} />
//                     </td>
//                     <td style={{ fontSize: 18, fontWeight: 700 }}>
//                       {item.name}
//                     </td>
//                     <td style={{ fontSize: 18, fontWeight: 700 }}>
//                       ${(item.price * item.quantity).toFixed(2)}
//                     </td>
//                     <td>
//                       <span
//                         style={{
//                           fontSize: 19,
//                           fontWeight: 700,
//                           display: "inline-block",
//                           width: 45,
//                         }}
//                       >
//                         {item.quantity}
//                       </span>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         </div>
//       )}
//             <h2 style={{ fontWeight: 900,marginLeft:50 }}>Subtotal: ₹{finalPrice}</h2>
//       <div className="cart-actions">

//         <Link to="/">
//           <button
//             className="btn btn-outline-success"
//             style={{ fontWeight: 900 }}
//           >
//             Continue Shopping
//           </button>
//         </Link>
//         <Link to="checkout">
//           <button
//             className="btn btn-outline-success"
//             style={{ fontWeight: 900 }}
//           >
//             Proceed to checkout
//           </button>
//         </Link>
//       </div>
//     </div>
//   );
// };

// export default CheckOutPage;

import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { decrement, increment, remove } from "../Store/Cartslice";
// import "./Cart.css";
import { Link } from "react-router-dom";

const CheckOutPage = () => {
  let names = useSelector((state) => state.cart);
  let dispatch = useDispatch();

  let updatePrice = names.reduce(
    (totalPrice, item) => totalPrice + item.price * item.quantity,
    0
  );

  let finalPrice = updatePrice.toFixed(0);
  return (
    <div className="container" style={{ margin: "0 auto" }}>
      <br /> <br />
      {names.length === 0 ? (
        <div className="empty-cart"></div>
      ) : (
        <div>
          <div className="cart-table">
            <table>
              <thead>
                <tr>
                  <th
                    style={{
                      fontWeight: 900,
                      fontSize: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    Product
                  </th>
                  <th
                    style={{
                      fontWeight: 900,
                      fontSize: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    Name
                  </th>
                  <th
                    style={{
                      fontWeight: 900,
                      fontSize: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    Quantity
                  </th>
                  <th
                    style={{
                      fontWeight: 900,
                      fontSize: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    Price
                  </th>
                </tr>
              </thead>

              <tbody style={{ borderTop: "2px solid black" }}>
                {names.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <img src={item.image} alt={item.name} />
                    </td>
                    <td style={{ fontSize: 18, fontWeight: 700 }}>
                      {item.name}
                    </td>
                    <td>
                      <span
                        style={{
                          fontSize: 19,
                          fontWeight: 700,
                          display: "inline-block",
                          width: 45,
                        }}
                      >
                        {item.quantity}
                      </span>
                    </td>
                    <td style={{ fontSize: 18, fontWeight: 700 }}>
                      ₹{(item.price * item.quantity).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <h5 style={{ fontWeight: 700, marginLeft: 50, marginTop: 20 }}>
            Shipping Charge: Free
          </h5>
          <hr />
          <h2 style={{ fontWeight: 900, marginLeft: 50, marginTop: 20 }}>
            Subtotal: ₹{finalPrice}
          </h2>
        </div>
      )}
    </div>
  );
};

export default CheckOutPage;
