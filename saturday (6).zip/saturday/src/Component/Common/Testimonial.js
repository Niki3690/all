import React from "react";
import { Carousel } from "react-bootstrap";
import images1 from "../images1.jpg";
import images2 from "../images2.jpg";
import images4 from "../images4.jpg";
import images6 from "../images6.jpg";
import Testimonialll from "../Testimoniallll.png";

const Testimonial = () => {
  return (
    <div>
      <h2
        style={{
          textAlign: "center",
          fontWeight: 800,
          fontSize: 40,
          marginBottom: 30,
        }}
      >
        Testimonial
      </h2>
      <div className="container">
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "600px 500px",
            gap: 45,
          }}
        >
          <div>
            <h3>
              What our{" "}
              <span style={{ color: "black", fontWeight: 900, fontSize: 40 }}>
                Customers
              </span>{" "}
              are saying
            </h3>

            <p style={{ marginTop: 15, lineHeight: 2 }}>
              Fresh Bites truly lives up to its name! bite bursts with freshness
              and flavor. From the crisp salads to the hearty sandwiches, each
              dish is a delightful journey for the taste buds.
            </p>

            <Carousel style={{ marginTop: 45 }}>
              <Carousel.Item style={{}}>
                <p style={{ lineHeight: 2 }}>
                  <b>
                    <q>
                      At Fresh Bites, customer satisfaction is paramount. From
                      the moment you place your order to the last bite, their
                      dedication to quality and service shines through. It's no
                      wonder they have a loyal following of satisfied customers!
                    </q>
                  </b>
                </p>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 15,
                  }}
                >
                  <img
                    src={images4}
                    alt="First slide"
                    style={{ height: 60, borderRadius: "10px", width: 67 }}
                  />
                  <h6 style={{ fontWeight: 700 }}>Vidhi Gohel</h6>
                </div>
              </Carousel.Item>
              <Carousel.Item style={{}}>
                <p style={{ lineHeight: 2 }}>
                  <b>
                    <q>
                      Fresh Bites combines convenience with quality like no
                      other. Ordering online is a breeze, and the food arrives
                      promptly, still retaining its freshness. It's the perfect
                      solution for busy days without compromising on taste.
                    </q>
                  </b>
                </p>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 15,
                  }}
                >
                  <img
                    src={images6}
                    alt="Second slide"
                    style={{ height: 60, borderRadius: "10px", width: 67 }}
                  />
                  <h6 style={{ fontWeight: 700 }}>Niki Patel</h6>
                </div>
              </Carousel.Item>
              <Carousel.Item style={{}}>
                <p style={{ lineHeight: 2 }}>
                  <b>
                    <q>
                      Fresh Bites redefines freshness with every dish. I
                      couldn't believe the difference in taste until I tried
                      their farm-to-table ingredients. It's like they've
                      captured the essence of freshness in every bite.
                    </q>
                  </b>
                </p>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 15,
                  }}
                >
                  <img
                    src={images1}
                    alt="Third slide"
                    style={{ height: 60, borderRadius: "10px", width: 67 }}
                  />
                  <h6 style={{ fontWeight: 700 }}>Vachan Patel</h6>
                </div>
              </Carousel.Item>
            </Carousel>
          </div>

          <div className="delllee">
            <img src={Testimonialll} style={{ height: 400 }} />
          </div>
        </div>
      </div>
      <br /> <br /> <br />
    </div>
  );
};

export default Testimonial;
