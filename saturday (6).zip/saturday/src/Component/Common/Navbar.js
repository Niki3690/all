// import React from "react";
// import { Link } from "react-router-dom";
// import "./Navbar.css";
// import { useSelector, useDispatch } from "react-redux";
// import { decrement, increment, remove } from "../Store/Cartslice";

// const Navbar = () => {
//   let names = useSelector((state) => state.cart);
//   let dispatch = useDispatch();
//   let Remove = (itemId) => {
//     dispatch(remove(itemId));
//   };

//   let INCR = (itemId) => {
//     dispatch(increment(itemId));
//   };
//   let DECR = (itemId) => {
//     dispatch(decrement(itemId));
//   };

//   let updatePrice = names.reduce(
//     (totalPrice, item) => totalPrice + item.price * item.quantity,
//     0
//   );

//   let finalPrice = updatePrice.toFixed(0);
//   return (
//     <div style={{ backgroundColor: "#EFEDED" }}>
//       <div className="navbar1">
//         <div>
//           <img
//             className="navbar12"
//             src="https://c8.alamy.com/comp/2E1ARYT/initial-vn-letter-logo-design-vector-template-abstract-script-letter-vn-logo-vector-2E1ARYT.jpg"
//             style={{ height: 50, width: 70 }}
//           />
//         </div>
//         <div className="names2">
//           <Link to="/">Home</Link>
//           <Link to="alldata">Shop</Link>
//           <Link to="about">About</Link>
//           <Link to="cart">Cart</Link>
//         </div>
//         <div>
//           <div style={{ display: "flex", gap: 15 }}>
//             <button
//               className="btn"
//               type="button"
//               data-bs-toggle="offcanvas"
//               data-bs-target="#offcanvasRight"
//               aria-controls="offcanvasRight"
//               style={{
//                 backgroundColor: "black",
//                 color: "#EFEDED",
//                 fontWeight: 800,
//                 marginTop: -2,
//                 position: "relative",
//               }}
//             >
//               <i
//                 className="fa-solid fa-basket-shopping"
//                 style={{ marginRight: "5px" }}
//               ></i>
//               <span
//                 style={{
//                   fontSize: "12px",
//                   position: "absolute",
//                   top: "-10px",
//                   right: "-10px",
//                   backgroundColor: "#0B5ED7",
//                   borderRadius: "100%",
//                   padding: "5px 8px",
//                   color: "white",
//                 }}
//               >
//                 {names.length}
//               </span>
//             </button>
//             <div
//               class="offcanvas offcanvas-end"
//               tabindex="-1"
//               id="offcanvasRight"
//               aria-labelledby="offcanvasRightLabel"
//               style={{ width: "38%" }}
//             >
//               <div class="offcanvas-header">
//                 <h5
//                   id="offcanvasRightLabel"
//                   style={{
//                     textAlign: "center",
//                     marginLeft: 145,
//                     fontWeight: 600,
//                   }}
//                 >
//                   CART ITEMS
//                 </h5>
//                 <button
//                   type="button"
//                   class="btn-close text-reset"
//                   data-bs-dismiss="offcanvas"
//                   aria-label="Close"
//                 ></button>
//               </div>
//               <div class="offcanvas-body">
//                 <table className="table">
//                   <thead>
//                     <tr>
//                       <th
//                         style={{
//                           fontWeight: 900,
//                           fontSize: 20,
//                           textTransform: "capitalize",
//                         }}
//                       >
//                         Images
//                       </th>
//                       <th
//                         style={{
//                           fontWeight: 900,
//                           fontSize: 20,
//                           textTransform: "capitalize",
//                         }}
//                       >
//                         Title
//                       </th>
//                       <th
//                         style={{
//                           fontWeight: 900,
//                           fontSize: 20,
//                           textTransform: "capitalize",
//                         }}
//                       >
//                         Price
//                       </th>
//                       <th
//                         style={{
//                           fontWeight: 900,
//                           fontSize: 20,
//                           textTransform: "capitalize",
//                         }}
//                       >
//                         Quantity
//                       </th>
//                       <th
//                         style={{
//                           fontWeight: 900,
//                           fontSize: 20,
//                           textTransform: "capitalize",
//                         }}
//                       >
//                         Remove
//                       </th>
//                     </tr>
//                   </thead>
//                   <tbody style={{ borderTop: "2px solid black" }}>
//                     <br />
//                     {names.length === 0 ? (
//                       <tr>
//                         <td
//                           colSpan="4"
//                           style={{
//                             textAlign: "center",
//                             fontSize: 35,
//                             marginTop: 100,
//                           }}
//                         >
//                           No data in cart
//                         </td>
//                       </tr>
//                     ) : (
//                       names.map((item) => (
//                         <tr key={item.id}>
//                           <td>
//                             {" "}
//                             <img
//                               src={item.image}
//                               alt={item.name}
//                               style={{ height: 45, width: 45 }}
//                             />
//                           </td>
//                           <td
//                             style={{ fontWeight: 600, width: 100, height: 60 }}
//                           >
//                             {item.name}
//                           </td>
//                           <td style={{ fontWeight: 600 }}>
//                             {(item.price * item.quantity).toFixed(0)}
//                           </td>
//                           <td>
//                             <button
//                               className="btn  btn-outline-success"
//                               onClick={() => INCR(item.id)}
//                               style={{ marginTop: -5 }}
//                             >
//                               +
//                             </button>
//                             <span
//                               style={{
//                                 margin: "0 11px",
//                                 marginTop: -25,
//                                 fontWeight: 600,
//                               }}
//                             >
//                               {item.quantity}
//                             </span>
//                             <button
//                               className="btn  btn-outline-success"
//                               onClick={() => DECR(item.id)}
//                               style={{ marginTop: -5 }}
//                             >
//                               -
//                             </button>
//                           </td>
//                           <td>
//                             <button
//                               className="btn  btn-outline-danger"
//                               onClick={() => Remove(item.id)}
//                               style={{ marginTop: -5 }}
//                             >
//                               <i className="fa-solid fa-trash"></i>
//                             </button>
//                           </td>
//                         </tr>
//                       ))
//                     )}
//                   </tbody>
//                 </table>

//                 <div
//                   style={{
//                     position: "absolute",
//                     bottom: 0,
//                     left: 0,
//                     width: "100%",
//                     height: 80,
//                     backgroundColor: "#EFEDED",
//                     paddingTop: 25,
//                     display: "flex",
//                     justifyContent: "center",
//                     textAlign: "center",
//                     alignItems: "center",
//                     gap: 45,
//                   }}
//                 >
//                   <Link to="#">
//                     <h2 style={{ fontWeight: 900 }}>Subtotal: ₹{finalPrice}</h2>
//                   </Link>
//                   <Link to="cart/checkout">
//                     <button
//                       className="btn btn-primary"
//                       style={{ marginTop: -15 }}
//                     >
//                       Chekout
//                     </button>
//                   </Link>
//                 </div>
//               </div>
//             </div>

//             <div></div>
//             <Link to="login">
//               <button
//                 style={{
//                   backgroundColor: "black",
//                   color: "#EFEDED",
//                   fontWeight: 800,
//                   marginTop: -2,
//                   padding: "2px 11px",
//                   borderRadius: 7,
//                 }}
//               >
//                 {" "}
//                 <i class="fa-solid fa-user"></i>
//               </button>
//             </Link>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Navbar;

import React from "react";
import { Link } from "react-router-dom";
import "./Navbar.css";
import { useSelector, useDispatch } from "react-redux";
import { decrement, increment, remove } from "../Store/Cartslice";

const Navbar = () => {
  let names = useSelector((state) => state.cart);
  let dispatch = useDispatch();
  let Remove = (itemId) => {
    dispatch(remove(itemId));
  };

  let INCR = (itemId) => {
    dispatch(increment(itemId));
  };
  let DECR = (itemId) => {
    dispatch(decrement(itemId));
  };

  let updatePrice = names.reduce(
    (totalPrice, item) => totalPrice + item.price * item.quantity,
    0
  );

  let finalPrice = updatePrice.toFixed(0);
  return (
    <div style={{ backgroundColor: "#EFEDED" }}>
      <div className="navbar1">
        <div>
          <img
            className="navbar12"
            src="https://c8.alamy.com/comp/2E1ARYT/initial-vn-letter-logo-design-vector-template-abstract-script-letter-vn-logo-vector-2E1ARYT.jpg"
            style={{ height: 50, width: 70 }}
          />
        </div>
        <div className="names2">
          <Link to="/">Home</Link>
          <Link to="alldata">Shop</Link>
          <Link to="about">About</Link>
          <Link to="cart">Cart</Link>
          <Link to="contactpage">Contact</Link>
        </div>
        <div>
          <div style={{ display: "flex", gap: 15 }}>
            <button
              className="btn"
              type="button"
              data-bs-toggle="offcanvas"
              data-bs-target="#offcanvasRight"
              aria-controls="offcanvasRight"
              style={{
                backgroundColor: "black",
                color: "#EFEDED",
                fontWeight: 800,
                marginTop: -2,
                position: "relative",
              }}
            >
              <i
                className="fa-solid fa-basket-shopping"
                style={{ marginRight: "5px" }}
              ></i>
              <span
                style={{
                  fontSize: "12px",
                  position: "absolute",
                  top: "-10px",
                  right: "-10px",
                  backgroundColor: "#0B5ED7",
                  borderRadius: "100%",
                  padding: "5px 8px",
                  color: "white",
                }}
              >
                {names.length}
              </span>
            </button>
            <div
              class="offcanvas offcanvas-end"
              tabindex="-1"
              id="offcanvasRight"
              aria-labelledby="offcanvasRightLabel"
              style={{ width: "38%" }}
            >
              <div class="offcanvas-header">
                <h5
                  id="offcanvasRightLabel"
                  style={{
                    textAlign: "center",
                    marginLeft: 145,
                    fontWeight: 600,
                  }}
                >
                  CART ITEMS
                </h5>
                <button
                  type="button"
                  class="btn-close text-reset"
                  data-bs-dismiss="offcanvas"
                  aria-label="Close"
                ></button>
              </div>
              <div class="offcanvas-body">
                {names.length === 0 ? (
                  <h3
                    colSpan="4"
                    style={{
                      textAlign: "center",
                      fontSize: 35,
                      marginTop: 100,
                    }}
                  >
                    Your cart is Empty
                  </h3>
                ) : (
                  <table className="table">
                    <thead>
                      <tr>
                        <th
                          style={{
                            fontWeight: 900,
                            fontSize: 20,
                            textTransform: "capitalize",
                          }}
                        >
                          Images
                        </th>
                        <th
                          style={{
                            fontWeight: 900,
                            fontSize: 20,
                            textTransform: "capitalize",
                          }}
                        >
                          Title
                        </th>
                        <th
                          style={{
                            fontWeight: 900,
                            fontSize: 20,
                            textTransform: "capitalize",
                          }}
                        >
                          Price
                        </th>
                        <th
                          style={{
                            fontWeight: 900,
                            fontSize: 20,
                            textTransform: "capitalize",
                          }}
                        >
                          Quantity
                        </th>
                        <th
                          style={{
                            fontWeight: 900,
                            fontSize: 20,
                            textTransform: "capitalize",
                          }}
                        >
                          Remove
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {names.map((item) => (
                        <tr key={item.id}>
                          <td>
                            {" "}
                            <img
                              src={item.image}
                              alt={item.name}
                              style={{ height: 45, width: 45 }}
                            />
                          </td>
                          <td
                            style={{ fontWeight: 600, width: 100, height: 60 }}
                          >
                            {item.name}
                          </td>
                          <td style={{ fontWeight: 600 }}>
                            ₹{(item.price * item.quantity).toFixed(0)}
                          </td>
                          <td>
                            <button
                              className="btn  btn-outline-success"
                              onClick={() => INCR(item.id)}
                              style={{
                                marginTop: -5,
                                borderRadius: "250px",
                                marginTop: -2,
                                fontWeight: 900,
                              }}
                            >
                              <i class="fa-solid fa-plus"></i>
                            </button>
                            <span
                              style={{
                                margin: "0 11px",
                                marginTop: -25,
                                fontWeight: 600,
                              }}
                            >
                              {item.quantity}
                            </span>
                            <button
                              className="btn  btn-outline-success"
                              onClick={() => DECR(item.id)}
                              style={{
                                marginTop: -5,
                                borderRadius: "250px",
                                marginTop: -2,
                                fontWeight: 900,
                              }}
                              disabled={item.quantity === 1}
                            >
                              <i class="fa-solid fa-minus"></i>
                            </button>
                          </td>
                          <td>
                            <button
                              className="btn  btn-outline-danger"
                              onClick={() => Remove(item.id)}
                              style={{
                                marginTop: -5,
                                borderRadius: "250px",
                                marginTop: -2,
                                fontWeight: 900,
                              }}
                            >
                              <i className="fa-solid fa-trash"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                <div
                  style={{
                    position: "absolute",
                    bottom: 0,
                    left: 0,
                    width: "100%",
                    height: 80,
                    backgroundColor: "#EFEDED",
                    paddingTop: 25,
                    display: "flex",
                    justifyContent: "center",
                    textAlign: "center",
                    alignItems: "center",
                    gap: 45,
                  }}
                >
                  <Link to="#">
                    <h2 style={{ fontWeight: 900 }}>Subtotal: ₹{finalPrice}</h2>
                  </Link>
                  <Link to="cart/checkout">
                    <button
                      className="btn btn-primary"
                      style={{ marginTop: -15 }}
                    >
                      Chekout
                    </button>
                  </Link>
                </div>
              </div>
            </div>

            <div></div>
            <Link to="login">
              <button
                style={{
                  backgroundColor: "black",
                  color: "#EFEDED",
                  fontWeight: 800,
                  marginTop: -2,
                  padding: "2px 11px",
                  borderRadius: 7,
                }}
              >
                {" "}
                <i class="fa-solid fa-user"></i>
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
