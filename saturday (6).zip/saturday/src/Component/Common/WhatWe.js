import React from "react";
import Delievery from "../Common/Delievery.png";
import Dinein from "../Common/Dinein.png";
import Pickup from "../Common/PickUp.png";
import bakerysnaks from "./assest/bakery-snacks.webp";
import softDrinks from "./assest/energy-soft-drinks.webp";
import freshVegetables from "./assest/fresh-vegetables.webp";
import freshFruits from "./assest/fresh-fruits.webp";

const WhatWe = () => {
  return (
    <div>
      <div style={{ textAlign: "center" }}>
        <h3>
          What we{" "}
          <span style={{ colorL: "black", fontWeight: 900 }}>Serve</span>
        </h3>

        <h1>
          <span style={{ fontSize: 37 }}>
            <span style={{ colorL: "black", fontWeight: 900 }}>Just</span> sit
            Back at Home
            <br />
          </span>
        </h1>

        <h3>
          We will{" "}
          <span style={{ colorL: "black", fontWeight: 900, fontSize: 45 }}>
            Take care
          </span>
        </h3>
      </div>
      <br />
      <br />

      <div
        style={{
          display: "flex",
          justifyContent: "space-evenly",
          textAlign: "center",
        }}
      >
        <div className="dellle">
          <img src={Delievery} style={{ height: 50, width: 60 }} />
          <h4 style={{ marginTop: 15 }}>Quick Delivery</h4>
          <p style={{ marginTop: 5 }}>
            Experience lightning-fast delivery
            <br /> with Fresh Bites, ensuring your
            <br /> meal arrives swiftly to your
            <br /> doorstep.
          </p>
        </div>

        <div className="dellle">
          <img src={Dinein} style={{ height: 50, width: 60 }} />
          <h4 style={{ marginTop: 15 }}>Super Dine In</h4>
          <p style={{ marginTop: 5 }}>
            Experience the ultimate diningaa
            <br /> convenience with Super Dine In,
            <br /> where delicious category a<br /> click away.
          </p>
        </div>

        <div className="dellle">
          <img src={Pickup} style={{ height: 50, width: 60 }} />
          <h4 style={{ marginTop: 15 }}>Easy Pick Up</h4>
          <p style={{ marginTop: 5 }}>
            Enjoy the convenience of easy pick-
            <br />
            up options, making your Fresh Bites
            <br /> experience even more seamless.
          </p>
        </div>
      </div>

      <div
        className="container"
        style={{
          display: "flex",
          gap: 25,
          textAlign: "center",
          justifyContent: "center",
          marginTop: 45,
        }}
      >
        <img
          className="cloths"
          src={freshFruits}
          style={{ width: 260, borderRadius: 10 }}
        />

        <img
          className="cloths"
          src={freshVegetables}
          style={{ width: 260, borderRadius: 10 }}
        />
        <img
          className="cloths"
          src={softDrinks}
          style={{ width: 260, borderRadius: 10 }}
        />
        <img
          className="cloths"
          src={bakerysnaks}
          style={{ width: 260, height: 70, borderRadius: 10 }}
        />
      </div>
    </div>
  );
};

export default WhatWe;
