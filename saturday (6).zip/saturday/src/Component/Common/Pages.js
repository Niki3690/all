import React from "react";

const Pages = () => {
  return (
    <div className="container">
      <div style={{ display: "flex", gap: 25, justifyContent: "center" }}>
        <div
          className="cloths"
          style={{
            height: 80,
            width: 200,
            backgroundColor: "black",
            color: "white",
            borderRadius: 6,
          }}
        >
          <div
            style={{
              display: "flex",
              textAlign: "center",
              justifyContent: "center",
              gap: 15,
              alignItems: "center",
              marginTop: 7,
            }}
          >
            <img
              src="https://t4.ftcdn.net/jpg/06/32/57/11/360_F_632571187_glzcmAoI5egceKDX23z0SxqpJUxAQPk4.jpg"
              style={{ height: 63, width: 63, borderRadius: "100%" }}
            />
            <h6 style={{ fontSize: 20, fontWeight: 600 }}>Fruits</h6>
          </div>
        </div>

        <div
          className="cloths"
          style={{
            height: 80,
            width: 200,
            backgroundColor: "black",
            color: "white",
            borderRadius: 6,
          }}
        >
          <div
            style={{
              display: "flex",
              textAlign: "center",
              justifyContent: "center",
              gap: 15,
              alignItems: "center",
              marginTop: 7,
            }}
          >
            <img
              src="https://media.istockphoto.com/id/589415708/photo/fresh-fruits-and-vegetables.jpg?s=612x612&w=0&k=20&c=aBFGUU-98pnoht73co8r2TZIKF3MDtBBu9KSxtxK_C0="
              style={{ height: 63, width: 63, borderRadius: "100%" }}
            />
            <h6 style={{ fontSize: 20, fontWeight: 600 }}>Vegitables</h6>
          </div>
        </div>

        <div
          className="cloths"
          style={{
            height: 80,
            width: 200,
            backgroundColor: "black",
            color: "white",
            borderRadius: 6,
          }}
        >
          <div
            style={{
              display: "flex",
              textAlign: "center",
              justifyContent: "center",
              gap: 15,
              alignItems: "center",
              marginTop: 7,
            }}
          >
            <img
              src="https://5.imimg.com/data5/SELLER/Default/2023/3/296872949/ZZ/GG/BW/77999044/cold-drink-recipe-formulation.jpeg"
              style={{ height: 63, width: 63, borderRadius: "100%" }}
            />
            <h6 style={{ fontSize: 20, fontWeight: 600 }}>Cold Drinks</h6>
          </div>
        </div>

        <div
          className="cloths"
          style={{
            height: 80,
            width: 200,
            backgroundColor: "black",
            color: "white",
            borderRadius: 6,
          }}
        >
          <div
            style={{
              display: "flex",
              textAlign: "center",
              justifyContent: "center",
              gap: 15,
              alignItems: "center",
              marginTop: 7,
            }}
          >
            <img
              src="https://www.kroger.com/product/images/large/front/0002840010416"
              style={{ height: 63, width: 63, borderRadius: "100%" }}
            />
            <h6 style={{ fontSize: 20, fontWeight: 600 }}>Chips</h6>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pages;
