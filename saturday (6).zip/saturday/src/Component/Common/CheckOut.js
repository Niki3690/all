import React, { useState } from "react";
import CheckOutPage from "./CheckOutPage";



const CheckOut = () => {
  let [text, setText] = useState("");
  let [email, setEmail] = useState("");
  let [number, setNumber] = useState("");
  let [country, setCountry] = useState("");
  let [city, setCity] = useState("");
  let [code, setCode] = useState("");
  let [error, setError] = useState(false);

  let ChnageFile = (e) => {
    e.preventDefault();

    if (
      text.length === 0 ||
      email.length === 0 ||
      number.length === 0 ||
      country.length === 0 ||
      city.length === 0 ||
      code.length === 0
    ) {
      setError(true);
    } else {
      setText("");
      setEmail("");
      setNumber("");
      setCountry("");
      setCity("");
      setCode("");
      alert("Address submitted successfully!");
    }
  };
  return (
    <div className="container">
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "600px 500px",
          justifyContent: "center",
        }}
      >
        <div>
          <div>
            <h4 style={{ fontWeight: 800, marginTop: 45 }}>Shipping Address</h4>

            <form onSubmit={ChnageFile}>
              <input
                type="text"
                placeholder="Enter your name"
                name="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                style={{
                  boxSizing: "borderBox",
                  border: "none",
                  borderBottom: "2px solid gray",
                  marginTop: 45,
                  width: 550,
                }}
              ></input>
              {error && text.length <= 0 ? (
                <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
                  please fill this field!
                </h6>
              ) : (
                ""
              )}
              <br /> <br />
              <input
                type="email"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                style={{
                  boxSizing: "borderBox",
                  border: "none",
                  borderBottom: "2px solid gray",
                  width: 550,
                }}
              ></input>
              {error && email.length <= 0 ? (
                <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
                  please fill this field!
                </h6>
              ) : (
                ""
              )}
              <br /> <br />
              <input
                type="number"
                name="number"
                value={number}
                onChange={(e) => setNumber(e.target.value)}
                placeholder="Phone number"
                style={{
                  boxSizing: "borderBox",
                  border: "none",
                  borderBottom: "2px solid gray",
                  width: 550,
                }}
              ></input>
              {error && number.length <= 0 ? (
                <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
                  please fill this field!
                </h6>
              ) : (
                ""
              )}
              <br /> <br />
              <input
                type="text"
                name="text"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                placeholder="Country"
                style={{
                  boxSizing: "borderBox",
                  border: "none",
                  borderBottom: "2px solid gray",
                  width: 550,
                }}
              ></input>
              {error && country.length <= 0 ? (
                <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
                  please fill this field!
                </h6>
              ) : (
                ""
              )}
              <br /> <br />
              <input
                type="text"
                name="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="City"
                style={{
                  boxSizing: "borderBox",
                  border: "none",
                  borderBottom: "2px solid gray",
                  width: 550,
                }}
              ></input>
              {error && city.length <= 0 ? (
                <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
                  please fill this field!
                </h6>
              ) : (
                ""
              )}
              <br /> <br />
              <input
                type="number"
                name="number"
                onChange={(e) => setCode(e.target.value)}
                value={code}
                placeholder="Postal code"
                style={{
                  boxSizing: "borderBox",
                  border: "none",
                  borderBottom: "2px solid gray",
                  width: 550,
                }}
              ></input>
              {error && code.length <= 0 ? (
                <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
                  please fill this field!
                </h6>
              ) : (
                ""
              )}
              <br /> <br />
              <button
                type="submit"
                style={{
                  marginTop: 45,
                  marginLeft: 25,
                  padding: "3px 15px",
                  fontWeight: 800,
                  fontSize: 22,
                }}
              >
                Payment
              </button>
            </form>
          </div>
          <div style={{ display: "flex", gap: 25, marginTop: 30 }}></div>
        </div>

        <div>
          <CheckOutPage />


        </div>
      </div>
    </div>
  );
};

export default CheckOut;

// import React, { useState } from "react";

// const CheckOut = () => {
// let [text, setText] = useState("");
// let [email, setEmail] = useState("");
// let [number, setNumber] = useState("");
// let [country, setCountry] = useState("");
// let [city, setCity] = useState("");
// let [code, setCode] = useState("");
// let [error, setError] = useState(false);

//   let ChnageFile = (e) => {
//   e.preventDefault();

//   if (
//     text.length === 0 ||
//     email.length === 0 ||
//     number.length === 0 ||
//     country.length === 0 ||
//     city.length === 0 ||
//     code.length === 0
//   ) {
//     setError(true);
//   } else {
//     setText("");
//     setEmail("");
//     setNumber("");
//     setCountry("");
//     setCity("");
//     setCode("");
//     alert("Address submitted successfully!");
//   }
// };
//   return (
//     <div className="container">
//       <div>
//         <h4 style={{ fontWeight: 800, marginTop: 45 }}>Shipping Address</h4>

//         <form onSubmit={ChnageFile}>
//           <input
//             type="text"
//             placeholder="Enter your name"
//             name="text"
//             value={text}
//             onChange={(e) => setText(e.target.value)}
//             style={{
//               boxSizing: "borderBox",
//               border: "none",
//               borderBottom: "2px solid gray",
//               marginTop: 45,
//               width: 550,
//             }}
//           ></input>
//           {error && text.length <= 0 ? (
//             <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
//               please fill this field!
//             </h6>
//           ) : (
//             ""
//           )}
//           <br /> <br />
//           <input
//             type="email"
//             name="email"
//             value={email}
//             onChange={(e) => setEmail(e.target.value)}
//             placeholder="Enter your email"
//             style={{
//               boxSizing: "borderBox",
//               border: "none",
//               borderBottom: "2px solid gray",
//               width: 550,
//             }}
//           ></input>
//           {error && email.length <= 0 ? (
//             <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
//               please fill this field!
//             </h6>
//           ) : (
//             ""
//           )}
//           <br /> <br />
//           <input
//             type="number"
//             name="number"
//             value={number}
//             onChange={(e) => setNumber(e.target.value)}
//             placeholder="Phone number"
//             style={{
//               boxSizing: "borderBox",
//               border: "none",
//               borderBottom: "2px solid gray",
//               width: 550,
//             }}
//           ></input>
//           {error && number.length <= 0 ? (
//             <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
//               please fill this field!
//             </h6>
//           ) : (
//             ""
//           )}
//           <br /> <br />
//           <input
//             type="text"
//             name="text"
//             value={country}
//             onChange={(e) => setCountry(e.target.value)}
//             placeholder="Country"
//             style={{
//               boxSizing: "borderBox",
//               border: "none",
//               borderBottom: "2px solid gray",
//               width: 550,
//             }}
//           ></input>
//           {error && country.length <= 0 ? (
//             <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
//               please fill this field!
//             </h6>
//           ) : (
//             ""
//           )}
//           <br /> <br />
//           <input
//             type="text"
//             name="text"
//             value={city}
//             onChange={(e) => setCity(e.target.value)}
//             placeholder="City"
//             style={{
//               boxSizing: "borderBox",
//               border: "none",
//               borderBottom: "2px solid gray",
//               width: 550,
//             }}
//           ></input>
//           {error && city.length <= 0 ? (
//             <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
//               please fill this field!
//             </h6>
//           ) : (
//             ""
//           )}
//           <br /> <br />
//           <input
//             type="number"
//             name="number"
//             onChange={(e) => setCode(e.target.value)}
//             value={code}
//             placeholder="Postal code"
//             style={{
//               boxSizing: "borderBox",
//               border: "none",
//               borderBottom: "2px solid gray",
//               width: 550,
//             }}
//           ></input>
//           {error && code.length <= 0 ? (
//             <h6 style={{ color: "red", marginLeft: 15, marginTop: 5 }}>
//               please fill this field!
//             </h6>
//           ) : (
//             ""
//           )}
//           <br /> <br />
//           <button
//             type="submit"
//             style={{
//               marginTop: 45,
//               marginLeft: 25,
//               padding: "3px 15px",
//               fontWeight: 800,
//               fontSize: 22,
//             }}
//           >
//             Payment
//           </button>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default CheckOut
