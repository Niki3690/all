import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { add, increment, decrement } from "../Store/Cartslice";
import { DATAAAAAA } from "./DATAAAAAAA";

const SinglePages = () => {
  const names = useSelector((state) => state.cart);
  const dispatch = useDispatch();
  const [findButton, setFindButton] = useState(DATAAAAAA);
  const [findInput, setFindInput] = useState("");
  const [selectPrice, setSelectPrice] = useState("");
  const { id } = useParams();
  const item = DATAAAAAA.find((item) => item.id == id);

  const ADD = (item) => {
    const items = names.find((cartItem) => cartItem.id === item.id);
    if (!items) {
      dispatch(add(item));
    } else {
      alert("This item is already in the cart!");
    }
  };

  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 2,
    className: "slider-container",
  };

  return (
    <div className="container" style={{ cursor: "pointer" }}>
      <div className="details11">
        <div className="detailss">
          <div
            style={{
              display: "flex",
              gap: 10,
              justifyContent: "space-evenly",
            }}
          >
            <div>
              <img src={item.image} style={{ height: 350, width: 480 }} />
            </div>

            <div>
              <h1 className="" style={{ marginTop: 35, fontWeight: 900 }}>
                {item.name}
              </h1>
              <br />
              <div style={{ display: "flex", gap: 25 }}>
                <h4>&#8377;{item.price}</h4>
                <h4>
                  &#8377;
                  <del style={{ fontWeight: 400 }}>{item.old}</del>
                </h4>
              </div>

              <br />

              <h5 style={{ fontWeight: 400 }}>{item.descripition}</h5>
              <br />
              <button
                className="btn btn-outline-primary"
                onClick={() => ADD(item)}
                style={{ marginTop: 5 }}
              >
                Add To Cart
              </button>
            </div>
          </div>
        </div>
      </div>
      <br /> <br /> <br />
      <br /> <br />
      <div>
        <Slider {...settings}>
          {findButton.map((item) => (
            <div key={item.id} className="details5">
              <div className="images7">
                <img
                  src={item.image}
                  style={{ height: 150, width: 245 }}
                  alt={item.name}
                />
              </div>
              <h4 className="titlee" style={{ textAlign: "center" }}>
                {item.name}
              </h4>

              <div
                style={{
                  display: "flex",
                  gap: 15,
                  justifyContent: "center",
                  marginTop: -19,
                }}
              >
                <h4>{item.price}</h4>
                <h4>
                  <del style={{ fontWeight: 400 }}>{item.old}</del>
                </h4>
              </div>

              <button
                className="btn  btn-outline-primary"
                onClick={() => ADD(item)}
                style={{ marginTop: 5, marginLeft: 78 }}
              >
                Add To Cart
              </button>
            </div>
          ))}
        </Slider>
      </div>
    </div>
  );
};

export default SinglePages;
