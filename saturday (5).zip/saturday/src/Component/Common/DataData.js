import React from "react";
import AlLDataa from "./AlLDataa";

const DataData = () => {
  return (
    <>
      <AlLDataa />
    </>
  );
};

export default DataData;
