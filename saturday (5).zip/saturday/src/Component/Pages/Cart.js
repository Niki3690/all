import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { decrement, increment, remove } from "../Store/Cartslice";
import "./Cart.css";
import { Link } from "react-router-dom";
import Cartt from "../cartt.jpg";

const Cart = () => {
  let names = useSelector((state) => state.cart);
  let dispatch = useDispatch();

  let Remove = (itemId) => {
    dispatch(remove(itemId));
  };

  let INCR = (itemId) => {
    dispatch(increment(itemId));
  };
  let DECR = (itemId) => {
    dispatch(decrement(itemId));
  };

  return (
    <div className="container" style={{ margin: "0 auto" }}>
      <br /> <br />
      <div>
        <div className="cart-table">
          <table>
            <thead>
              <tr>
                <th>Product</th>
                <th>Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Remove</th>
              </tr>
            </thead>
            <tbody>
              {names.length === 0 ? (
                <tr>
                  <td colSpan="5" className="empty-cart">
                    <img
                      src="https://img.freepik.com/free-vector/supermarket-shopping-cart-concept-illustration_114360-22408.jpg"
                      style={{ height: 200, width: 200 }}
                      alt="Empty Cart"
                    />
                    <h5>Your cart is empty</h5>
                  </td>
                </tr>
              ) : (
                names.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <img src={item.image} alt={item.name} />
                    </td>
                    <td style={{ fontSize: 20, fontWeight: 700 }}>
                      {item.name}
                    </td>
                    <td style={{ fontSize: 20, fontWeight: 700 }}>
                      ${(item.price * item.quantity).toFixed(2)}
                    </td>
                    <td>
                      <button
                        className="btn btn-outline-primary"
                        style={{
                          borderRadius: "250px",
                          marginTop: -2,
                          fontWeight: 900,
                        }}
                        onClick={() => DECR(item.id)}
                        disabled={item.quantity === 1}
                      >
                        -
                      </button>
                      <span
                        style={{
                          marginLeft: 20,
                          marginRight: 20,
                          fontSize: 25,
                          fontWeight: 700,
                        }}
                      >
                        {item.quantity}
                      </span>
                      <button
                        className="btn btn-outline-primary"
                        style={{
                          borderRadius: "250px",
                          marginTop: -2,
                          fontWeight: 900,
                        }}
                        onClick={() => INCR(item.id)}
                      >
                        +
                      </button>
                    </td>
                    <td>
                      <button
                        className="btn btn-outline-primary"
                        style={{
                          borderRadius: "250px",
                          marginTop: -2,
                          fontWeight: 900,
                        }}
                        onClick={() => Remove(item.id)}
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
      <div className="cart-actions">
        <Link to="/">
          <button
            className="btn btn-outline-primary"
            style={{ fontWeight: 900 }}
          >
            Continue Shopping
          </button>
        </Link>
        <Link to="checkout">
          <button
            className="btn btn-outline-primary"
            style={{ fontWeight: 900 }}
          >
            Proceed to checkout
          </button>
        </Link>
      </div>
    </div>
  );
};

export default Cart;
