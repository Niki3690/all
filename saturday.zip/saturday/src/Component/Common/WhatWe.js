import React from "react";
import Delievery from "../Common/Delievery.png";
import Dinein from "../Common/Dinein.png";
import Pickup from "../Common/PickUp.png";

const WhatWe = () => {
  return (
    <div>
      <div style={{ textAlign: "center" }}>
        <h2>
          What we{" "}
          <span style={{ colorL: "black", fontWeight: 900 }}>Serve</span>
        </h2>

        <h1>
          <span style={{ fontSize: 42 }}>
            <span style={{ colorL: "black", fontWeight: 900 }}>Just</span> sit
            Back at Home
            <br />
          </span>
        </h1>

        <h2>
          We will{" "}
          <span style={{ colorL: "black", fontWeight: 900, fontSize: 45 }}>
            Take care
          </span>
        </h2>
      </div>
      <br />
      <br />

      <div
        style={{
          display: "flex",
          justifyContent: "space-evenly",
          textAlign: "center",
        }}
      >
        <div className="dellle">
          <img src={Delievery} style={{ height: 50, width: 60 }} />
          <h4 style={{ marginTop: 15 }}>Quick Delivery</h4>
          <p style={{ marginTop: 5 }}>
            Experience lightning-fast delivery
            <br /> with Fresh Bites, ensuring your
            <br /> meal arrives swiftly to your
            <br /> doorstep.
          </p>
        </div>

        <div  className="dellle">
          <img src={Dinein} style={{ height: 50, width: 60 }} />
          <h4 style={{ marginTop: 15 }}>Super Dine In</h4>
          <p style={{ marginTop: 5 }}>
            Experience the ultimate diningaa
            <br /> convenience with Super Dine In,
            <br /> where delicious category a<br /> click away.
          </p>
        </div>

        <div  className="dellle">
          <img src={Pickup} style={{ height: 50, width: 60 }} />
          <h4 style={{ marginTop: 15 }}>Easy Pick Up</h4>
          <p style={{ marginTop: 5 }}>
            Enjoy the convenience of easy pick-
            <br />
            up options, making your Fresh Bites
            <br /> experience even more seamless.
          </p>
        </div>
      </div>
    </div>
  );
};

export default WhatWe;
