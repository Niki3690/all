import React from "react";
import { DataDetail } from "./DataDetail";
import "./DataData.css";
import { useState } from "react";
import { add } from "../Store/Cartslice";
import { useDispatch, useSelector } from "react-redux";

const AlLDataa = () => {
  let names = useSelector((state) => state.cart);
  let dispatch = useDispatch();
  let [findButton, setFindButton] = useState(DataDetail);
  let [findInput, setFindInput] = useState("");
  let [selectPrice, setSelectPrice] = useState("");

  let ADD = (item) => {
    let items = names.find((cartItem) => cartItem.id === item.id);
    if (!items) {
      dispatch(add(item));
    }
  };

  let ClickButton = (num) => {
    let numberr = DataDetail.filter((nn) => nn.category === num);
    setFindButton(numberr);
  };

  let InputValue = (e) => {
    setFindInput(e.target.value);

    let num1 = DataDetail.filter((num1) =>
      num1.title.toLowerCase().includes(e.target.value.toLowerCase())
    );
    setFindButton(num1);
  };

  let CHNAGES = (e) => {
    setSelectPrice(e.target.value);

    let num11 = DataDetail.filter((items) => {
      if (e.target.value === "") {
        return true;
      } else if (e.target.value === "0-30") {
        return items.price >= 0 && items.price <= 30;
      } else if (e.target.value === "30-50") {
        return items.price >= 30 && items.price <= 50;
      } else if (e.target.value === "50-70") {
        return items.price >= 50 && items.price <= 70;
      } else if (e.target.value === "70-90") {
        return items.price >= 70 && items.price <= 90;
      }
    });
    setFindButton(num11);
  };

  return (
    <div>
      <div className="butttton1">
        <button onClick={() => setFindButton(DataDetail)}>All</button>
        <button onClick={() => ClickButton("Electronics")}>
          <i class="fa-solid fa-plug"></i> Electronics
        </button>
        <button onClick={() => ClickButton("Clothing")}>
          <i class="fa-solid fa-shirt"></i> Clothing
        </button>
        <button onClick={() => ClickButton("Toys")}>
          <i class="fa-solid fa-gamepad"></i> Toys
        </button>
        <button onClick={() => ClickButton("Home")}>
          <i class="fa-solid fa-house"></i> Home
        </button>
        <button onClick={() => ClickButton("Books")}>
          <i class="fa-solid fa-book"></i> Books
        </button>
        <input
          className="nnnnnn"
          type="text"
          placeholder="search here.."
          value={findInput}
          onChange={InputValue}
        />

        <select value={selectPrice} onChange={CHNAGES}>
          <option value="">All Price</option>
          <option value="0-30">0-30</option>
          <option value="30-50">30-50</option>
          <option value="50-70">50-70</option>
          <option value="70-90">70-90</option>
        </select>
      </div>

      <div className="details1">
        {findButton.map((item) => {
          return (
            <div className="details2">
              <h4 className="titlee">{item.title}</h4>
              <h3 style={{ marginTop: -10 }}>{item.category}</h3>
              <h4>{item.price}</h4>

              <button
                className="btn btn-primary"
                onClick={() => ADD(item)}
                style={{ marginTop: 5 }}
              >
                Add To Cart
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AlLDataa;
