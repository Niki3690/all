import React from "react";
import { useParams } from "react-router-dom";
import { DataDetail } from "./DataDetail";
import "./SinglePages.css";

const SinglePages = () => {
  let { id } = useParams();
  let item = DataDetail.find((item) => item.id == id);
  return (
    <div className="container">
      <div className="details11">
        <div className="detailss">
          <h2 style={{ textAlign: "center", fontWeight: 900 }}>{item.id}</h2>
          <h4 className="" style={{ marginTop: 35 }}>
            {" "}
            <span style={{ color: "black", fontSize: 25, fontWeight: 800 }}>
              Title:
            </span>{" "}
            {item.title}
          </h4>
          <h5>
            <span style={{ color: "black", fontSize: 25, fontWeight: 800 }}>
              Categoty:
            </span>{" "}
            {item.category}
          </h5>
          <h5>
            <span style={{ color: "black", fontSize: 25, fontWeight: 800 }}>
              Price:
            </span>{" "}
            {item.price}
          </h5>
          <h5>
            <span style={{ color: "black", fontSize: 25, fontWeight: 800 }}>
              Rate:
            </span>{" "}
            {item.rate}
          </h5>
          <h5>
            <span style={{ color: "black", fontSize: 25, fontWeight: 800 }}>
              Description:
            </span>{" "}
            {item.description}
          </h5>
        </div>
      </div>
    </div>
  );
};

export default SinglePages;
