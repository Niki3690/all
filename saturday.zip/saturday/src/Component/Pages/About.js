import React from "react";
import { motion, Variants } from "framer-motion";
const About = () => {
  let Animation: Variants = {
    hide: {
      opacity: 0,
      y: 200,
    },
    show: {
      opacity: 1,
      y: 0,
      transition: {
        staggerChildren: 0.3,
        duration: 1.5,
      },
    },
  };
  return (
    <motion.div
      style={{ textAlign: "center", marginTop: 45 }}
      variants={Animation}
      initial="hide"
      animate="show"
    >
      <motion.h3 variants={Animation}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit.
      </motion.h3>
      <motion.h3 variants={Animation}>
        Lorem ipsum dolor sit amet consectetur adipisicing.
      </motion.h3>
      <motion.h3 variants={Animation}>
        Lorem ipsum dolor sit amet consectetur.
      </motion.h3>
      <motion.h3 variants={Animation}>Lorem ipsum dolor sit amet.</motion.h3>
      <motion.h3 variants={Animation}>Lorem ipsum dolor sit.</motion.h3>
      <motion.h3 variants={Animation}>Lorem ipsum dolor.</motion.h3>
      <motion.h3 variants={Animation}>Lorem ipsum.</motion.h3>
      <motion.h3 variants={Animation}>Lorem.</motion.h3>
    </motion.div>
  );
};

export default About;
