import React from "react";

const LoginPage = () => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "50vh",
      }}
    >
      <div
        style={{
          border: "2px solid gray",
          width: 350,
          textAlign: "center",
          padding: 15,
        }}
      >
        <input
          type="text"
          placeholder="Email"
          name="text"
          style={{
            boxSizing: "border-box",
            border: "none",
            borderBottom: "2px solid gray",
            marginTop: 45,
            width: 250,
            marginBottom: 20,
          }}
        />
        <br />
        <input
          type="text"
          placeholder="Password"
          name="text"
          style={{
            boxSizing: "border-box",
            border: "none",
            borderBottom: "2px solid gray",
            marginTop: 20,
            width: 250,
          }}
        />
        <br />
        <br />

        <button className="btn btn-primary">Login</button>
      </div>
    </div>
  );
};

export default LoginPage;
